import shutil
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB = BASE_DIR / "data" / "commercial.db"
IMAGES = BASE_DIR / "data" / "images"
BACKUP_DIR = BASE_DIR / "backups"
BACKUP_DIR.mkdir(exist_ok=True)


def backup_database():
    """Zip the database + product images into one backup file."""
    if not DB.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = BACKUP_DIR / f"commercial_{stamp}"
    stage = BACKUP_DIR / f"_stage_{stamp}"
    (stage / "data").mkdir(parents=True, exist_ok=True)
    shutil.copy2(DB, stage / "data" / "commercial.db")
    if IMAGES.exists():
        shutil.copytree(IMAGES, stage / "data" / "images", dirs_exist_ok=True)
    archive = shutil.make_archive(str(target), "zip", str(stage))
    shutil.rmtree(stage)
    return Path(archive)


def list_backups():
    return sorted(BACKUP_DIR.glob("*.zip"), reverse=True)


def restore_backup(zip_path):
    """Restore db + images from a backup zip. Caller must restart the app after."""
    import zipfile
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(BASE_DIR / "_restore_tmp")
    tmp = BASE_DIR / "_restore_tmp" / "data"
    if (tmp / "commercial.db").exists():
        shutil.copy2(tmp / "commercial.db", DB)
    if (tmp / "images").exists():
        shutil.copytree(tmp / "images", IMAGES, dirs_exist_ok=True)
    shutil.rmtree(BASE_DIR / "_restore_tmp")
