"""PI and catalog PDF generation with Persian text support (reportlab)."""
import datetime as dt
import re
from pathlib import Path
from xml.sax.saxutils import escape

import arabic_reshaper
from bidi.algorithm import get_display
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.fonts import addMapping
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image as RLImage, PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle)

from database import BASE_DIR

FONT_DIR = BASE_DIR / "fonts"
_REG = [FONT_DIR / "Vazirmatn-Regular.ttf", "C:/Windows/Fonts/tahoma.ttf", "C:/Windows/Fonts/arial.ttf",
        "/Library/Fonts/Arial Unicode.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
_BOLD = [FONT_DIR / "Vazirmatn-Bold.ttf", "C:/Windows/Fonts/tahomabd.ttf", "C:/Windows/Fonts/arialbd.ttf",
         "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def _first(paths):
    return next((str(p) for p in paths if Path(p).exists()), None)


def _setup_fonts():
    reg = _first(_REG)
    if not reg:
        return "Helvetica", "Helvetica-Bold"
    bold = _first(_BOLD) or reg
    pdfmetrics.registerFont(TTFont("AppF", reg))
    pdfmetrics.registerFont(TTFont("AppFB", bold))
    for b, i, f in ((0, 0, "AppF"), (1, 0, "AppFB"), (0, 1, "AppF"), (1, 1, "AppFB")):
        addMapping("AppF", b, i, f)
    return "AppF", "AppFB"


F, FB = _setup_fonts()
NAVY, GOLD, LIGHT, GREY = (colors.HexColor("#0B2545"), colors.HexColor("#C9A227"),
                          colors.HexColor("#EEF2F7"), colors.HexColor("#6B7280"))
_AR = re.compile(r"[\u0600-\u06FF]")


def fa(t):
    t = "" if t is None else str(t)
    return get_display(arabic_reshaper.reshape(t)) if _AR.search(t) else t


def P(t, style):
    lines = "<br/>".join(escape(fa(x)) for x in ("" if t is None else str(t)).split("\n"))
    return Paragraph(lines, style)


def styles():
    b = ParagraphStyle("b", fontName=F, fontSize=8.5, leading=11)
    return {"n": b, "b": ParagraphStyle("bb", parent=b, fontName=FB),
            "h1": ParagraphStyle("h1", parent=b, fontName=FB, fontSize=15, leading=19, textColor=NAVY),
            "h2": ParagraphStyle("h2", parent=b, fontName=FB, fontSize=11, leading=14, textColor=NAVY),
            "title": ParagraphStyle("t", parent=b, fontName=FB, fontSize=20, leading=24, textColor=NAVY,
                                    alignment=2),
            "w": ParagraphStyle("w", parent=b, fontName=FB, textColor=colors.white),
            "wl": ParagraphStyle("wl", parent=b, fontName=FB, fontSize=16, leading=20, textColor=colors.white),
            "r": ParagraphStyle("r", parent=b, alignment=2),
            "rb": ParagraphStyle("rb", parent=b, fontName=FB, alignment=2),
            "c": ParagraphStyle("c", parent=b, alignment=1),
            "small": ParagraphStyle("s", parent=b, fontSize=7.5, leading=9.5, textColor=GREY)}


def rl_image(path, maxw, maxh):
    if not path:
        return None
    p = Path(path)
    if not p.is_absolute():
        p = BASE_DIR / "data" / path
    if not p.exists():
        return None
    try:
        iw, ih = ImageReader(str(p)).getSize()
    except Exception:
        return None
    k = min(maxw / iw, maxh / ih)
    return RLImage(str(p), width=iw * k, height=ih * k)


def qr(data, size=80):
    w = QrCodeWidget(data)
    x0, y0, x1, y1 = w.getBounds()
    d = Drawing(size, size, transform=[size / (x1 - x0), 0, 0, size / (y1 - y0), 0, 0])
    d.add(w)
    return d


def num(x, d=2):
    try:
        return f"{float(x):,.{d}f}"
    except (TypeError, ValueError):
        return ""


def qty(x):
    try:
        return f"{float(x):,.3f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return ""


# ------------------------------------------------------------------ PI
def _addr(c):
    return ", ".join(x for x in (c.address, c.city, c.country) if x) if c else ""


def build_pi_pdf(pi, me, path):
    s, c = styles(), pi
    d0 = dt.datetime.strptime(c.pi_date, "%Y-%m-%d").date() if c.pi_date else dt.date.today()
    valid = d0 + dt.timedelta(days=c.validity_days or 0)
    buyer, consignee = c.buyer, c.consignee or c.buyer
    buyer_contact = buyer.contacts[0].full_name if buyer and buyer.contacts else ""
    cons_contact = consignee.contacts[0].full_name if consignee and consignee.contacts else ""
    total_qty = sum((i.qty or 0) for i in c.items)

    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=14 * mm, bottomMargin=14 * mm, title=f"PI {c.pi_no}")
    W = A4[0] - 28 * mm
    story = []
    logo = rl_image(me.logo, 45 * mm, 22 * mm)
    seller = [P(me.name, s["h1"]), P(me.address, s["n"]),
              P(" | ".join(x for x in (me.phone, me.email, me.website) if x), s["small"])]
    meta = [P("PROFORMA INVOICE", s["title"]), Spacer(1, 3), P(f"PI No: {c.pi_no}", s["rb"]),
            P(f"Date: {d0.strftime('%d %b %Y')}", s["r"]), P(f"Validity: {valid.strftime('%d %b %Y')}", s["r"])]
    head = Table([[logo or "", seller, meta]], colWidths=[W * .2, W * .42, W * .38])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, 0), 1.2, NAVY),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
    story += [head, Spacer(1, 8)]

    def party(title, comp, contact):
        return [P(title, s["w"]), P(comp.company_name_fa if comp else "", s["b"]), P(_addr(comp), s["n"]),
                P(" | ".join(x for x in ((comp.phone if comp else ""), (comp.email if comp else "")) if x), s["small"]),
                P(f"Attn: {contact}" if contact else "", s["small"])]
    b, cn = party("BUYER", buyer, buyer_contact), party("CONSIGNEE", consignee, cons_contact)
    pt = Table([[b[0], cn[0]], [b[1:], cn[1:]]], colWidths=[W / 2] * 2)
    pt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), .5, NAVY),
                            ("INNERGRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [pt, Spacer(1, 8)]

    hdr = ["No", "Description", "Specification", "Qty", "Unit", f"Unit Price ({c.currency})", f"Amount ({c.currency})"]
    rows = [[P(h, s["w"]) for h in hdr]]
    for n, i in enumerate(c.items):
        rows.append([P(n + 1, s["c"]), P(i.description, s["n"]), P(i.spec, s["small"]), P(qty(i.qty), s["r"]),
                     P(i.unit, s["c"]), P(num(i.unit_price), s["r"]), P(num(i.amount), s["r"])])
    rows.append(["", "", P("TOTAL", s["rb"]), P(qty(total_qty), s["rb"]), "", "", P(f"{c.currency} {num(c.total)}", s["rb"])])
    it = Table(rows, colWidths=[W * .05, W * .25, W * .23, W * .09, W * .08, W * .15, W * .15], repeatRows=1)
    it.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), NAVY), ("GRID", (0, 0), (-1, -2), .25, colors.grey),
                            ("BACKGROUND", (0, -1), (-1, -1), LIGHT), ("BOX", (0, -1), (-1, -1), .5, NAVY),
                            ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    story += [it, Spacer(1, 8)]

    terms = [("Incoterm", c.incoterm), ("Payment Terms", c.payment_terms), ("Delivery", c.delivery),
             ("Packing", c.packing), ("Origin", c.origin), ("Port of Loading", c.loading_port),
             ("Port of Discharge", c.discharge_port), ("Validity", valid.strftime("%d %b %Y"))]
    tt = Table([[P(k, s["b"]), P(v, s["n"])] for k, v in terms if v], colWidths=[W * .25, W * .75])
    tt.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("BACKGROUND", (0, 0), (0, -1), LIGHT)]))
    story += [P("TERMS & CONDITIONS", s["h2"]), Spacer(1, 3), tt, Spacer(1, 8)]

    bank = [(k, v) for k, v in [("Bank", me.bank_name), ("Beneficiary", me.beneficiary),
                                ("Account No", me.account_no), ("IBAN", me.iban), ("SWIFT", me.swift),
                                ("Bank Address", me.bank_address)] if v]
    if bank:
        bt = Table([[P(k, s["b"]), P(v, s["n"])] for k, v in bank], colWidths=[W * .25, W * .75])
        bt.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("BACKGROUND", (0, 0), (0, -1), LIGHT)]))
        story += [P("BANK DETAILS", s["h2"]), Spacer(1, 3), bt, Spacer(1, 8)]
    if c.remark:
        story += [P("REMARKS", s["h2"]), Spacer(1, 3), P(c.remark, s["n"]), Spacer(1, 8)]
    sig = Table([[P("Buyer's signature & stamp", s["small"]), P(f"For {me.name}", s["r"])]],
               colWidths=[W / 2] * 2, rowHeights=[28 * mm])
    sig.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LINEABOVE", (0, 0), (-1, 0), .5, colors.grey)]))
    story.append(sig)
    doc.build(story)
    return path


# ------------------------------------------------------------------ Catalog
def build_catalog(products, me, path, tagline="", about="", markets="", trading="", show_price=False):
    s = styles()
    name = me.name or "Company"
    tagline = tagline or "Oil & Petrochemical Products"

    def cover(cv, doc):
        w, h = A4
        cv.setFillColor(NAVY); cv.rect(0, 0, w, h, fill=1, stroke=0)
        cv.setFillColor(GOLD); cv.rect(0, h * .42, w, 5 * mm, fill=1, stroke=0)
        y = h * .82
        if me.logo:
            p = Path(me.logo)
            p = p if p.is_absolute() else BASE_DIR / "data" / me.logo
            if p.exists():
                try:
                    iw, ih = ImageReader(str(p)).getSize()
                    k = min(60 * mm / iw, 40 * mm / ih)
                    cv.drawImage(str(p), (w - iw * k) / 2, y - ih * k / 2, iw * k, ih * k, mask="auto")
                except Exception:
                    pass
        cv.setFillColor(colors.white); cv.setFont(FB, 30); cv.drawCentredString(w / 2, h * .34, fa(name))
        cv.setFillColor(GOLD); cv.setFont(F, 15); cv.drawCentredString(w / 2, h * .29, fa(tagline))
        cv.setFillColor(colors.white); cv.setFont(F, 9)
        cv.drawCentredString(w / 2, 20 * mm, fa(" | ".join(x for x in (me.website, me.email) if x)))
        cv.drawCentredString(w / 2, h * .12, f"PRODUCT CATALOG {dt.date.today().year}")

    def inner(cv, doc):
        w, h = A4
        cv.setFillColor(NAVY); cv.rect(0, h - 12 * mm, w, 12 * mm, fill=1, stroke=0)
        cv.setFillColor(GOLD); cv.rect(0, h - 13.2 * mm, w, 1.2 * mm, fill=1, stroke=0)
        cv.setFillColor(colors.white); cv.setFont(FB, 9); cv.drawString(15 * mm, h - 8 * mm, fa(name))
        cv.setFont(F, 8); cv.drawRightString(w - 15 * mm, h - 8 * mm, fa(tagline))
        cv.setFillColor(GREY); cv.setFont(F, 8); cv.drawCentredString(w / 2, 8 * mm, str(doc.page))

    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=22 * mm, bottomMargin=16 * mm, title=f"{name} Catalog")
    W = A4[0] - 30 * mm
    story = [PageBreak()]

    def bar(text):
        t = Table([[P(text, s["wl"])]], colWidths=[W], rowHeights=[12 * mm])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY), ("LINEBELOW", (0, 0), (-1, -1), 2, GOLD),
                               ("LEFTPADDING", (0, 0), (-1, -1), 8), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
        return t

    story += [bar("Company Profile"), Spacer(1, 8), P("About Us", s["h2"]), P(about or me.about or "", s["n"]),
              Spacer(1, 8), P("Our Products", s["h2"])]
    story += [P("• " + (p.name_en or p.name_fa), s["n"]) for p in products]
    if trading:
        story += [Spacer(1, 8), P("Trading Activities", s["h2"]), P(trading, s["n"])]
    if markets or me.markets:
        story += [Spacer(1, 8), P("Markets", s["h2"]), P(markets or me.markets, s["n"])]
    story.append(PageBreak())

    for p in products:
        story += [bar((p.name_en or p.name_fa).upper()), Spacer(1, 8)]
        if p.images:
            main = rl_image(p.images[0].path, W * .55, 75 * mm)
            side = [x for x in (rl_image(i.path, W * .38, 34 * mm) for i in p.images[1:3]) if x]
            if main:
                row = Table([[main, side or ""]], colWidths=[W * .58, W * .42])
                row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("ALIGN", (0, 0), (-1, -1), "CENTER")]))
                story += [row, Spacer(1, 8)]
        if p.description:
            story += [P("Description", s["h2"]), P(p.description, s["n"]), Spacer(1, 8)]
        if p.specifications:
            has_m = any(x.method for x in p.specifications)
            rows = [[P("Property", s["w"]), P("Specification", s["w"])] + ([P("Method", s["w"])] if has_m else [])]
            for x in p.specifications:
                rows.append([P(x.parameter, s["n"]), P(x.value, s["n"])] + ([P(x.method, s["small"])] if has_m else []))
            cw = [W * .4, W * .3, W * .3] if has_m else [W * .5, W * .5]
            t = Table(rows, colWidths=cw, repeatRows=1)
            t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), NAVY), ("GRID", (0, 0), (-1, -1), .25, colors.lightgrey),
                                   ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT])]))
            story += [P("Specification", s["h2"]), Spacer(1, 3), t, Spacer(1, 8)]
        facts = [("Packaging", p.packaging), ("Origin", p.origin), ("Loading Port", p.loading_port),
                 ("MOQ", p.moq), ("HS Code", p.hs_code), ("Incoterm", p.incoterm)]
        if show_price and p.price:
            facts.append(("Price", f"{p.currency or ''} {num(p.price)} / {p.unit or ''}"))
        facts = [(k, v) for k, v in facts if v]
        if facts:
            ft = Table([[P(k, s["b"]), P(v, s["n"])] for k, v in facts], colWidths=[W * .3, W * .7])
            ft.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("BACKGROUND", (0, 0), (0, -1), LIGHT)]))
            story.append(ft)
        story.append(PageBreak())

    contact = [(k, v) for k, v in [("Website", me.website), ("Email", me.email),
                                   ("Telephone", me.phone), ("Address", me.address),
                                   ("WhatsApp", me.whatsapp), ("LinkedIn", me.linkedin)] if v]
    if contact:
        ct = Table([[P(k, s["b"]), P(v, s["n"])] for k, v in contact], colWidths=[W * .25, W * .75])
        ct.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), .25, colors.lightgrey), ("TOPPADDING", (0, 0), (-1, -1), 6)]))
        story += [bar("Contact Us"), Spacer(1, 12), ct, Spacer(1, 16)]
    else:
        story.append(bar("Contact Us"))
    if me.website:
        w = me.website if me.website.startswith("http") else "https://" + me.website
        story.append(Table([[qr(w, 90)]], colWidths=[W]))
    doc.build(story, onFirstPage=cover, onLaterPages=inner)
    return path
