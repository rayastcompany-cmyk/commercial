import re
from openpyxl import load_workbook, Workbook
from models import Company, Contact, CompanyRole, Product, ProductSpecification

# Each entry: (field_key, display_label, [keyword aliases used only to *guess* a default
# mapping — the user can always remap any column manually, so no exact header is required).
# Order matters: fields with narrower/more specific keywords are listed before fields with
# broad generic keywords (e.g. "name") so the specific ones claim their column first.
FIELD_DEFS_COMPANY = [
    ("company_name_en", "نام انگلیسی", ["english", "انگلیسی"]),
    ("manager", "مدیرعامل / مدیر", ["مدیرعامل", "مدیر عامل", "manager", "ceo", "مدیر"]),
    ("mobile", "موبایل", ["موبایل", "mobile", "cell"]),
    ("phone", "تلفن", ["تلفن", "phone", "tel"]),
    ("email", "ایمیل", ["ایمیل", "email", "mail"]),
    ("website", "وب‌سایت", ["وب سایت", "وب‌سایت", "website", "site", "url"]),
    ("whatsapp", "واتساپ", ["واتساپ", "whatsapp"]),
    ("linkedin", "لینکدین", ["لینکدین", "linkedin"]),
    ("country", "کشور", ["کشور", "country"]),
    ("city", "شهر", ["شهر", "city"]),
    ("address", "آدرس", ["آدرس", "address"]),
    ("products_text", "محصولات", ["محصول", "product"]),
    ("public_relation", "روابط عمومی", ["روابط عمومی", "public relation", "publicrelation"]),
    ("company_type", "نوع فعالیت", ["نوع فعالیت", "نوع شرکت", "company type", "activity"]),
    ("tax_id", "شناسه مالیاتی", ["مالیات", "tax id", "taxid", "tax"]),
    ("registration_no", "شماره ثبت", ["شماره ثبت", "ثبت", "registration"]),
    ("role", "نقش", ["نقش", "role"]),
    ("description", "توضیحات", ["توضیح", "description", "note", "comment"]),
    ("company_name_fa", "نام شرکت *", ["نام شرکت", "نام فارسی", "company name", "نام", "name"]),
]

PRODUCT_FIELD_DEFS = [
    ("name_en", "نام انگلیسی", ["english", "انگلیسی"]),
    ("product_code", "کد محصول", ["کد محصول", "product code", "کد"]),
    ("hs_code", "HS Code", ["hs code", "hscode", "hs"]),
    ("subcategory", "زیردسته", ["زیردسته", "subcategory"]),
    ("category", "دسته‌بندی", ["دسته بندی", "دسته‌بندی", "دسته", "category"]),
    ("origin", "مبدأ", ["مبدا", "مبدأ", "origin"]),
    ("packaging", "بسته‌بندی", ["بسته بندی", "بسته‌بندی", "packaging"]),
    ("moq", "حداقل سفارش", ["حداقل سفارش", "moq"]),
    ("unit", "واحد", ["واحد", "unit"]),
    ("currency", "ارز", ["ارز", "currency"]),
    ("price", "قیمت", ["قیمت", "price"]),
    ("incoterm", "Incoterm", ["incoterm"]),
    ("loading_port", "بندر بارگیری", ["بندر بارگیری", "loading port"]),
    ("destination", "مقصد", ["مقصد", "destination"]),
    ("description", "توضیحات", ["توضیح", "description"]),
    ("spec1_name", "پارامتر ۱", ["spec1 name", "spec1name", "مشخصه ۱ نام", "پارامتر1"]),
    ("spec1_value", "مقدار ۱", ["spec1 value", "spec1value", "مقدار1"]),
    ("spec1_method", "روش تست ۱", ["spec1 method", "spec1method", "روش1"]),
    ("spec2_name", "پارامتر ۲", ["spec2 name", "spec2name", "پارامتر2"]),
    ("spec2_value", "مقدار ۲", ["spec2 value", "spec2value", "مقدار2"]),
    ("spec2_method", "روش تست ۲", ["spec2 method", "spec2method", "روش2"]),
    ("spec3_name", "پارامتر ۳", ["spec3 name", "spec3name", "پارامتر3"]),
    ("spec3_value", "مقدار ۳", ["spec3 value", "spec3value", "مقدار3"]),
    ("spec3_method", "روش تست ۳", ["spec3 method", "spec3method", "روش3"]),
    ("name_fa", "نام محصول *", ["نام محصول", "نام فارسی", "product name", "نام", "name"]),
]


def clean(v):
    if v is None:
        return ""
    s = str(v).strip()
    return re.sub(r"^mailto:", "", s, flags=re.I)


def normalize(s):
    return re.sub(r"[\s\u200c\u200f\u200e]+", "", clean(s)).strip().lower()


def read_raw(path, sheet=None):
    """Read the raw headers and data rows of a worksheet, no assumptions about column names.
    Returns (sheet_names, headers, data_rows) for the chosen sheet (first sheet by default)."""
    wb = load_workbook(path, read_only=True, data_only=True)
    sheet_names = wb.sheetnames
    ws = wb[sheet] if sheet else wb.worksheets[0]
    rows_iter = ws.iter_rows(values_only=True)
    try:
        raw_headers = list(next(rows_iter))
    except StopIteration:
        return sheet_names, [], []
    headers = [clean(h) or f"ستون {i + 1}" for i, h in enumerate(raw_headers)]
    data_rows = []
    for vals in rows_iter:
        if not any(v not in (None, "") for v in vals):
            continue
        vals = list(vals) + [None] * (len(headers) - len(vals))
        data_rows.append(vals[:len(headers)])
    return sheet_names, headers, data_rows


def guess_mapping(headers, field_defs):
    """Best-effort auto mapping from column headers to field keys, using keyword aliases
    purely as a *suggestion*. Nothing here requires an exact header — every field can be
    left unmapped or remapped by the user to any column."""
    norm_headers = [normalize(h) for h in headers]
    claimed = set()
    mapping = {}
    for key, _label, keywords in field_defs:
        found = None
        for i, nh in enumerate(norm_headers):
            if i in claimed or not nh:
                continue
            if any(normalize(kw) in nh for kw in keywords):
                found = i
                break
        mapping[key] = found
        if found is not None:
            claimed.add(found)
    return mapping


def apply_mapping(data_rows, mapping):
    """Turn raw data rows + a {field_key: column_index_or_None} mapping into the list of
    dicts that import_companies / import_products expect."""
    result = []
    for vals in data_rows:
        row = {}
        for key, idx in mapping.items():
            row[key] = clean(vals[idx]) if idx is not None and idx < len(vals) else ""
        result.append(row)
    return result


def import_companies(session, rows):
    added = updated = skipped = 0
    for row in rows:
        name = clean(row.get("company_name_fa"))
        if not name:
            skipped += 1
            continue
        company = session.query(Company).filter(Company.company_name_fa == name).first()
        data = {k: clean(row.get(k)) for k in
                ["company_name_fa", "company_name_en", "country", "city", "phone", "mobile",
                 "email", "address", "website", "products_text", "public_relation",
                 "description", "company_type", "tax_id", "registration_no"]}
        data = {k: v for k, v in data.items() if v}
        if company:
            for k, v in data.items():
                setattr(company, k, v)
            updated += 1
        else:
            company = Company(**data)
            session.add(company)
            session.flush()
            added += 1
        role = clean(row.get("role"))
        if role and not session.query(CompanyRole).filter_by(company_id=company.id, role=role).first():
            session.add(CompanyRole(company_id=company.id, role=role))
        manager = clean(row.get("manager"))
        if manager:
            parts = manager.split(maxsplit=1)
            first, last = (parts[0], parts[1]) if len(parts) > 1 else (parts[0], "")
            exists = session.query(Contact).filter_by(company_id=company.id, first_name=first,
                                                       last_name=last).first()
            if not exists:
                session.add(Contact(company_id=company.id, first_name=first, last_name=last,
                                    position="مدیرعامل", is_decision_maker=True))
    session.commit()
    return added, updated, skipped


def make_sample_products_excel(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Products"
    headers = ["نام محصول", "نام انگلیسی", "کد محصول", "HS Code", "دسته‌بندی", "زیردسته", "مبدأ",
              "بسته‌بندی", "حداقل سفارش", "واحد", "قیمت", "ارز", "Incoterm", "بندر بارگیری", "مقصد",
              "توضیحات", "Spec1 Name", "Spec1 Value", "Spec1 Method", "Spec2 Name", "Spec2 Value",
              "Spec2 Method", "Spec3 Name", "Spec3 Value", "Spec3 Method"]
    ws.append(headers)
    ws.append(["HDPE F7000", "HDPE F7000", "HD-F7000", "3901.20", "پلیمر", "HDPE", "Iran", "25kg bags",
              "1 Container", "MT", 1100, "USD", "FOB", "Bandar Abbas", "", "Film grade HDPE",
              "Density", "952", "ISO 1183", "MFR", "0.04", "ISO 1133", "", "", ""])
    for col, w in zip(ws.columns, [22, 18, 14, 10, 14, 12, 10, 14, 14, 8, 10, 8, 10, 16, 14, 24,
                                   16, 12, 14, 16, 12, 14, 16, 12, 14]):
        ws.column_dimensions[col[0].column_letter].width = w
    wb.save(str(path))
    return path


def import_products(session, rows):
    added = updated = skipped = 0
    for row in rows:
        name = clean(row.get("name_fa")) or clean(row.get("name_en"))
        if not name:
            skipped += 1
            continue
        is_fa = bool(clean(row.get("name_fa")))
        product = session.query(Product).filter(
            (Product.name_fa == name) | (Product.name_en == name)).first()
        data = {k: clean(row.get(k)) for k in
                ["name_fa", "name_en", "product_code", "hs_code", "category", "subcategory", "origin",
                 "packaging", "moq", "unit", "currency", "incoterm", "loading_port", "destination",
                 "description"]}
        data = {k: v for k, v in data.items() if v}
        if not data.get("name_fa"):
            data["name_fa"] = name if is_fa else (clean(row.get("name_en")) or name)
        price = clean(row.get("price"))
        if price:
            try:
                data["price"] = float(str(price).replace(",", ""))
            except ValueError:
                pass
        if product:
            for k, v in data.items():
                setattr(product, k, v)
            updated += 1
        else:
            product = Product(**data)
            session.add(product)
            session.flush()
            added += 1
        for i in (1, 2, 3):
            pname = clean(row.get(f"spec{i}_name"))
            if not pname:
                continue
            pval = clean(row.get(f"spec{i}_value"))
            pmethod = clean(row.get(f"spec{i}_method"))
            existing_spec = session.query(ProductSpecification).filter_by(
                product_id=product.id, parameter=pname).first()
            if existing_spec:
                existing_spec.value, existing_spec.method = pval, pmethod
            else:
                session.add(ProductSpecification(product_id=product.id, parameter=pname, value=pval,
                                                  method=pmethod, sort=i - 1))
    session.commit()
    return added, updated, skipped
