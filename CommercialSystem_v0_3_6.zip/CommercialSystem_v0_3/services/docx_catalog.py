"""Editable Word (.docx) product catalog — cover, about, table of contents, one page per
product (5-column bilingual spec table), and a contact page. Styled in an original color
palette (deep teal + copper) rather than copying any reference catalog's exact colors."""
import re
import datetime as dt
from pathlib import Path

from docx import Document
from docx.shared import Pt, Mm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from database import BASE_DIR

# ------------------------------------------------------------------ palette (original, not copied)
PRIMARY = "123B39"     # deep teal
PRIMARY_DARK = "0B2624"
ACCENT = "C97A3D"      # warm copper
LIGHT_BG = "F2EFE9"    # warm off-white for zebra rows
WHITE = "FFFFFF"
GREY = "6B7280"
BORDER_GREY = "D9D3C8"
FONT = "Tahoma"

_AR = re.compile(r"[\u0600-\u06FF]")
_UNIT_RE = re.compile(r"^(.*?)\s*\(([^)]+)\)\s*$")


def is_fa(text):
    return bool(_AR.search(text or ""))


def split_unit(param):
    """'Density (kg/m3)' -> ('Density', 'kg/m3'); no parens -> (param, '')."""
    m = _UNIT_RE.match((param or "").strip())
    return (m.group(1).strip(), m.group(2).strip()) if m else ((param or "").strip(), "")


# ------------------------------------------------------------------ low-level oxml helpers
def set_bidi(paragraph):
    pPr = paragraph._p.get_or_add_pPr()
    pPr.append(OxmlElement("w:bidi"))


def set_table_rtl(table):
    table._tbl.tblPr.append(OxmlElement("w:bidiVisual"))


def shade_cell(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def shade_run(run, hex_color):
    rPr = run._element.get_or_add_rPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_color)
    rPr.append(shd)


def cell_vcenter(cell):
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def set_col_widths(table, widths):
    table.autofit = False
    for row in table.rows:
        for cell, w in zip(row.cells, widths):
            cell.width = w


def set_table_fixed_width(table, total_width):
    """Force the table's overall width (not just per-cell) so it doesn't stretch to the
    page width — needed for anything narrower than the full content area, like the stat box."""
    tblPr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    tblW = OxmlElement("w:tblW")
    tblW.set(qn("w:type"), "dxa")
    tblW.set(qn("w:w"), str(int(total_width.twips if hasattr(total_width, "twips") else total_width)))
    tblPr.append(tblW)


def para(container, text="", size=10.5, bold=False, italic=False, color=None, align=WD_ALIGN_PARAGRAPH.RIGHT,
          space_after=4, font=FONT, rtl=None):
    """rtl=None auto-detects from the text (Persian -> bidi paragraph, plain Latin/numeric ->
    left-to-right run) so mixed content like '0.1 mm' or 'ISO 1133' never gets its internal
    character order flipped by Word's bidi algorithm. Pass True/False to force either way."""
    p = container.add_paragraph()
    use_rtl = is_fa(text) if rtl is None else rtl
    if use_rtl:
        set_bidi(p)
    p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    if text:
        r = p.add_run(text)
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.italic = italic
        r.font.name = font
        r._element.rPr.rFonts.set(qn("w:cs"), font)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
    return p


def page_break(doc):
    doc.add_page_break()


def set_doc_rtl_and_size(doc):
    for section in doc.sections:
        section.page_width = Mm(210)
        section.page_height = Mm(297)
        section.left_margin = Mm(18)
        section.right_margin = Mm(18)
        section.top_margin = Mm(16)
        section.bottom_margin = Mm(16)
        sectPr = section._sectPr
        sectPr.append(OxmlElement("w:bidi"))
    normal = doc.styles["Normal"]
    normal.font.name = FONT
    normal.font.size = Pt(10.5)
    rpr = normal.element.get_or_add_rPr()
    rpr.rFonts.set(qn("w:cs"), FONT)
    h1 = doc.styles["Heading 1"]
    h1.font.name = FONT
    h1.font.size = Pt(17)
    h1.font.bold = True
    h1.font.color.rgb = RGBColor.from_string(PRIMARY)
    h1.element.get_or_add_rPr().rFonts.set(qn("w:cs"), FONT)


def accent_bar(doc, height_mm=3.5, color=ACCENT):
    t = doc.add_table(rows=1, cols=1)
    t.autofit = False
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    row = t.rows[0]
    row.height = Mm(height_mm)
    cell = t.cell(0, 0)
    shade_cell(cell, color)
    cell.text = ""
    sectPr_width = doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin
    set_col_widths(t, [sectPr_width])
    return t


def tag_run(paragraph, text, bg=ACCENT, fg=WHITE, size=9, bold=True):
    r = paragraph.add_run(f" {text} ")
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.name = FONT
    r._element.rPr.rFonts.set(qn("w:cs"), FONT)
    r.font.color.rgb = RGBColor.from_string(fg)
    shade_run(r, bg)
    return r


# ------------------------------------------------------------------ cover
def build_cover(doc, me, tagline, product_count):
    page_w = doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin
    t = doc.add_table(rows=1, cols=1)
    t.autofit = False
    row = t.rows[0]
    row.height = Mm(255)
    from docx.oxml.ns import qn as _qn
    trPr = row._tr.get_or_add_trPr()
    trHeight = trPr.find(_qn("w:trHeight"))
    if trHeight is not None:
        trHeight.set(_qn("w:hRule"), "exact")
    cell = t.cell(0, 0)
    set_col_widths(t, [page_w])
    shade_cell(cell, PRIMARY)
    cell_vcenter(cell)
    cell.text = ""
    p0 = cell.paragraphs[0]
    p0.alignment = WD_ALIGN_PARAGRAPH.CENTER

    logo = me.logo
    if logo:
        p = (BASE_DIR / "data" / logo)
        if p.exists():
            pic_p = cell.add_paragraph()
            pic_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = pic_p.add_run()
            try:
                run.add_picture(str(p), width=Mm(32))
            except Exception:
                pass

    para(cell, me.name or "Company", size=30, bold=True, color=WHITE, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
    if me.name_fa and me.name_fa != me.name:
        para(cell, me.name_fa, size=15, bold=True, color=WHITE, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=14)
    para(cell, "PRODUCT CATALOG", size=12, bold=True, color=ACCENT, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
    para(cell, "کاتالوگ محصولات", size=13, bold=True, color=WHITE, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=18)
    if tagline:
        para(cell, tagline, size=11, color=WHITE, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=30)

    date_p = cell.add_paragraph()
    date_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tag_run(date_p, dt.date.today().strftime("%Y-%m-%d"), bg=ACCENT, fg=WHITE, size=10)

    foot_p = cell.add_paragraph()
    foot_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    foot_p.paragraph_format.space_before = Pt(20)
    r = foot_p.add_run(" | ".join(x for x in (me.website, me.email) if x))
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor.from_string("DCE6E4")
    r.font.name = FONT
    r._element.rPr.rFonts.set(qn("w:cs"), FONT)
    page_break(doc)


# ------------------------------------------------------------------ about
def build_about(doc, me, about, markets, trading, product_count):
    tag_p = doc.add_paragraph()
    set_bidi(tag_p)
    tag_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    tag_run(tag_p, "About Us  |  درباره ما")
    para(doc, "", size=4)

    text = about or (me.about or "")
    if text:
        para(doc, text, size=11)
    if trading:
        para(doc, "فعالیت‌های بازرگانی", size=12, bold=True, color=PRIMARY, space_after=2)
        para(doc, trading, size=11)
    if markets or me.markets:
        para(doc, "بازارهای هدف", size=12, bold=True, color=PRIMARY, space_after=2)
        para(doc, markets or me.markets, size=11)

    para(doc, "", size=6)
    page_w = doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin
    stat_t = doc.add_table(rows=1, cols=1)
    set_table_rtl(stat_t)
    stat_t.alignment = WD_TABLE_ALIGNMENT.RIGHT
    c = stat_t.cell(0, 0)
    shade_cell(c, PRIMARY)
    cell_vcenter(c)
    set_col_widths(stat_t, [Mm(55)])
    set_table_fixed_width(stat_t, Mm(55))
    stat_t.rows[0].height = Mm(20)
    c.text = ""
    para(c, str(product_count), size=20, bold=True, color=WHITE, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=0)
    para(c, "محصول", size=10, bold=True, color=ACCENT, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=0)
    page_break(doc)


# ------------------------------------------------------------------ table of contents (live Word field)
def build_toc(doc):
    tag_p = doc.add_paragraph()
    set_bidi(tag_p)
    tag_run(tag_p, "Contents  |  فهرست مطالب")
    para(doc, "برای نمایش شماره صفحه‌ها، روی فهرست کلیک راست کرده و «به‌روزرسانی فیلد» (Update Field) را بزنید.",
        size=9, italic=True, color=GREY)

    p = doc.add_paragraph()
    set_bidi(p)
    run = p.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = 'TOC \\o "1-1" \\h \\z \\u'
    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    fld_text = OxmlElement("w:t")
    fld_text.text = "برای مشاهده فهرست، فیلد را به‌روزرسانی کنید."
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    r_el = run._r
    r_el.append(fld_begin)
    r_el.append(instr)
    r_el.append(fld_sep)
    r_el.append(fld_text)
    r_el.append(fld_end)
    page_break(doc)


# ------------------------------------------------------------------ product pages
def build_product_page(doc, p, show_price=False):
    accent_bar(doc)
    para(doc, "", size=3)

    title = p.name_fa if is_fa(p.name_fa or "") else (p.name_en or p.name_fa or "")
    h = doc.add_heading(level=1)
    set_bidi(h)
    h.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    hr = h.add_run(title or "")
    hr.font.name = FONT
    hr._element.rPr.rFonts.set(qn("w:cs"), FONT)

    if p.name_en and p.name_en != title:
        para(doc, p.name_en, size=10.5, italic=True, color=GREY, space_after=3)

    tag_p = doc.add_paragraph()
    set_bidi(tag_p)
    tag_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if p.category:
        tag_run(tag_p, p.category, bg=PRIMARY, fg=WHITE, size=9)
    if p.unit:
        r = tag_p.add_run(f"   واحد: {p.unit}")
        r.font.size = Pt(9.5)
        r.font.name = FONT
        r._element.rPr.rFonts.set(qn("w:cs"), FONT)
        r.font.color.rgb = RGBColor.from_string(GREY)

    if p.description:
        para(doc, p.description, size=10.5, space_after=8)
    else:
        para(doc, "", size=4)

    specs = list(p.specifications)
    if specs:
        headers = ["عنوان", "عنوان (EN)", "واحد", "مشخصات", "روش تست"]
        t = doc.add_table(rows=1 + len(specs), cols=5)
        set_table_rtl(t)
        t.style = "Table Grid"
        page_w = doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin
        widths = [int(page_w * r) for r in (0.24, 0.20, 0.12, 0.22, 0.22)]
        set_col_widths(t, widths)
        for i, htxt in enumerate(headers):
            c = t.cell(0, i)
            c.text = ""
            shade_cell(c, PRIMARY)
            cell_vcenter(c)
            para(c, htxt, size=9.5, bold=True, color=WHITE, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=0)
        for ridx, sp in enumerate(specs, start=1):
            base, unit = split_unit(sp.parameter or "")
            fa_name = base if is_fa(base) else ""
            en_name = base if not is_fa(base) else ""
            row_vals = [fa_name, en_name, unit, sp.value or "", sp.method or ""]
            for cidx, val in enumerate(row_vals):
                c = t.cell(ridx, cidx)
                c.text = ""
                cell_vcenter(c)
                if ridx % 2 == 0:
                    shade_cell(c, LIGHT_BG)
                align = WD_ALIGN_PARAGRAPH.CENTER if cidx != 0 else WD_ALIGN_PARAGRAPH.RIGHT
                para(c, val, size=9.5, align=align, space_after=0)
        para(doc, "", size=6)

    facts = [("بسته‌بندی", p.packaging), ("مبدأ", p.origin), ("بندر بارگیری", p.loading_port),
             ("حداقل سفارش", p.moq), ("HS Code", p.hs_code), ("Incoterm", p.incoterm)]
    if show_price and p.price:
        facts.append(("قیمت", f"{p.currency or ''} {p.price:,.2f} / {p.unit or ''}"))
    facts = [(k, v) for k, v in facts if v]
    if facts:
        ft = doc.add_table(rows=len(facts), cols=2)
        set_table_rtl(ft)
        ft.style = "Table Grid"
        page_w = doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin
        set_col_widths(ft, [int(page_w * 0.3), int(page_w * 0.7)])
        for i, (k, v) in enumerate(facts):
            kc, vc = ft.cell(i, 0), ft.cell(i, 1)
            shade_cell(kc, LIGHT_BG)
            kc.text = ""
            vc.text = ""
            para(kc, k, size=9.5, bold=True, space_after=0)
            para(vc, v, size=9.5, space_after=0)
    page_break(doc)


# ------------------------------------------------------------------ contact page
def build_contact(doc, me):
    tag_p = doc.add_paragraph()
    set_bidi(tag_p)
    tag_run(tag_p, "Contact Us  |  تماس با ما")
    para(doc, "", size=6)

    contact = [(k, v) for k, v in [("وب‌سایت", me.website), ("ایمیل", me.email), ("تلفن", me.phone),
                                   ("آدرس", me.address), ("واتساپ", me.whatsapp), ("لینکدین", me.linkedin)] if v]
    if contact:
        t = doc.add_table(rows=len(contact), cols=2)
        set_table_rtl(t)
        t.style = "Table Grid"
        page_w = doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin
        set_col_widths(t, [int(page_w * 0.25), int(page_w * 0.75)])
        for i, (k, v) in enumerate(contact):
            kc, vc = t.cell(i, 0), t.cell(i, 1)
            shade_cell(kc, PRIMARY)
            kc.text = ""
            vc.text = ""
            para(kc, k, size=10, bold=True, color=WHITE, space_after=0)
            para(vc, v, size=10, space_after=0)
    else:
        para(doc, "اطلاعات تماس ثبت نشده است. از صفحه «شرکت من» می‌توانید آن را تکمیل کنید.", size=10, color=GREY)


# ------------------------------------------------------------------ entry point
def build_catalog_docx(products, me, path, tagline="", about="", markets="", trading="", show_price=False):
    doc = Document()
    set_doc_rtl_and_size(doc)
    build_cover(doc, me, tagline, len(products))
    build_about(doc, me, about, markets, trading, len(products))
    if len(products) > 1:
        build_toc(doc)
    for p in products:
        build_product_page(doc, p, show_price)
    build_contact(doc, me)
    doc.save(str(path))
    return path
