"""Fill a user-provided raw Word PI template with database data."""
import copy
import datetime as dt

PLACEHOLDERS = ["pi_no", "pi_date", "validity", "currency", "incoterm", "payment_terms", "delivery",
                "packing", "origin", "loading_port", "discharge_port", "remark", "total", "total_qty",
                "seller_name", "seller_address", "seller_phone", "seller_email", "seller_website",
                "buyer_name", "buyer_address", "buyer_country", "buyer_phone", "buyer_email", "buyer_contact",
                "consignee_name", "consignee_address", "consignee_country", "consignee_phone",
                "consignee_email", "consignee_contact", "bank_name", "beneficiary", "account_no", "iban",
                "swift", "bank_address"]
ITEM_PLACEHOLDERS = ["item_no", "item_description", "item_spec", "item_qty", "item_unit",
                     "item_unit_price", "item_amount"]


def _addr(c):
    return ", ".join(x for x in (c.address, c.city, c.country) if x) if c else ""


def pi_context(pi, me):
    d0 = dt.datetime.strptime(pi.pi_date, "%Y-%m-%d").date() if pi.pi_date else dt.date.today()
    valid = d0 + dt.timedelta(days=pi.validity_days or 0)
    buyer, consignee = pi.buyer, pi.consignee or pi.buyer
    total_qty = sum((i.qty or 0) for i in pi.items)
    ctx = {
        "pi_no": pi.pi_no, "pi_date": d0.strftime("%d %b %Y"), "validity": valid.strftime("%d %b %Y"),
        "currency": pi.currency or "", "incoterm": pi.incoterm or "", "payment_terms": pi.payment_terms or "",
        "delivery": pi.delivery or "", "packing": pi.packing or "", "origin": pi.origin or "",
        "loading_port": pi.loading_port or "", "discharge_port": pi.discharge_port or "",
        "remark": pi.remark or "", "total": f"{pi.total or 0:,.2f}", "total_qty": f"{total_qty:,.3f}".rstrip("0").rstrip("."),
        "seller_name": me.name or "", "seller_address": me.address or "", "seller_phone": me.phone or "",
        "seller_email": me.email or "", "seller_website": me.website or "",
        "buyer_name": buyer.company_name_fa if buyer else "", "buyer_address": _addr(buyer),
        "buyer_country": buyer.country if buyer else "", "buyer_phone": buyer.phone if buyer else "",
        "buyer_email": buyer.email if buyer else "",
        "buyer_contact": buyer.contacts[0].full_name if buyer and buyer.contacts else "",
        "consignee_name": consignee.company_name_fa if consignee else "", "consignee_address": _addr(consignee),
        "consignee_country": consignee.country if consignee else "", "consignee_phone": consignee.phone if consignee else "",
        "consignee_email": consignee.email if consignee else "",
        "consignee_contact": consignee.contacts[0].full_name if consignee and consignee.contacts else "",
        "bank_name": me.bank_name or "", "beneficiary": me.beneficiary or "", "account_no": me.account_no or "",
        "iban": me.iban or "", "swift": me.swift or "", "bank_address": me.bank_address or "",
    }
    ctx["items"] = [{"no": n + 1, "description": i.description or "", "spec": i.spec or "",
                     "qty": f"{i.qty or 0:,.3f}".rstrip("0").rstrip("."), "unit": i.unit or "",
                     "unit_price": f"{i.unit_price or 0:,.2f}", "amount": f"{i.amount or 0:,.2f}"}
                    for n, i in enumerate(pi.items)]
    return ctx


def _fill_par(p, ctx):
    if "{{" not in p.text:
        return
    text = p.text
    for k, v in ctx.items():
        text = text.replace("{{%s}}" % k, str(v))
    if p.runs:
        p.runs[0].text = text
        for r in p.runs[1:]:
            r.text = ""


def _walk(container, ctx):
    for p in container.paragraphs:
        _fill_par(p, ctx)
    for t in container.tables:
        for row in t.rows:
            for cell in row.cells:
                _walk(cell, ctx)


def fill_docx_template(template, ctx, out):
    from docx import Document
    from docx.table import _Row
    doc = Document(str(template))
    flat = {k: v for k, v in ctx.items() if k != "items"}
    for t in doc.tables:
        for row in list(t.rows):
            if any("{{item_" in c.text for c in row.cells):
                tr = row._tr
                for it in ctx["items"]:
                    new = copy.deepcopy(tr)
                    tr.addprevious(new)
                    ictx = {f"item_{k}": v for k, v in it.items()}
                    for cell in _Row(new, t).cells:
                        for p in cell.paragraphs:
                            _fill_par(p, ictx)
                tr.getparent().remove(tr)
                break
    _walk(doc, flat)
    for sec in doc.sections:
        _walk(sec.header, flat)
        _walk(sec.footer, flat)
    doc.save(str(out))
    return out


def make_sample_template(path):
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    d = Document()
    d.add_heading("PROFORMA INVOICE", 0).alignment = WD_ALIGN_PARAGRAPH.CENTER
    d.add_paragraph("{{seller_name}}\n{{seller_address}}\n{{seller_phone}} | {{seller_email}}")
    d.add_paragraph("PI No: {{pi_no}}      Date: {{pi_date}}      Validity: {{validity}}")
    t = d.add_table(rows=2, cols=2)
    t.style = "Table Grid"
    t.cell(0, 0).text, t.cell(0, 1).text = "BUYER", "CONSIGNEE"
    t.cell(1, 0).text = "{{buyer_name}}\n{{buyer_address}}\nTel: {{buyer_phone}}"
    t.cell(1, 1).text = "{{consignee_name}}\n{{consignee_address}}\nTel: {{consignee_phone}}"
    d.add_paragraph()
    it = d.add_table(rows=2, cols=7)
    it.style = "Table Grid"
    for i, h in enumerate(["No", "Description", "Specification", "Qty", "Unit", "Unit Price", "Amount"]):
        it.cell(0, i).text = h
    for i, k in enumerate(ITEM_PLACEHOLDERS):
        it.cell(1, i).text = "{{%s}}" % k
    d.add_paragraph("Total: {{currency}} {{total}}")
    d.add_paragraph("Incoterm: {{incoterm}}\nPayment: {{payment_terms}}\nDelivery: {{delivery}}\n"
                    "Packing: {{packing}}\nOrigin: {{origin}}\nLoading Port: {{loading_port}}\n"
                    "Discharge Port: {{discharge_port}}")
    d.add_paragraph("Bank: {{bank_name}}\nBeneficiary: {{beneficiary}}\nAccount: {{account_no}}\n"
                    "IBAN: {{iban}}\nSWIFT: {{swift}}\n{{bank_address}}")
    d.add_paragraph("Remarks: {{remark}}")
    d.save(str(path))
    return path


def docx_to_pdf(path):
    import shutil
    import subprocess
    from pathlib import Path
    exe = (shutil.which("soffice") or shutil.which("libreoffice") or
           next((p for p in ("C:/Program Files/LibreOffice/program/soffice.exe",
                             "C:/Program Files (x86)/LibreOffice/program/soffice.exe",
                             "/Applications/LibreOffice.app/Contents/MacOS/soffice") if Path(p).exists()), None))
    if not exe:
        return None
    path = Path(path)
    try:
        subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", str(path.parent), str(path)],
                       check=True, timeout=180, capture_output=True)
    except Exception:
        return None
    pdf = path.with_suffix(".pdf")
    return pdf if pdf.exists() else None
