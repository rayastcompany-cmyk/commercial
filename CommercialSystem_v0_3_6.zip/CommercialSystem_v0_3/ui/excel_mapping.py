"""Reusable 'match your Excel columns to our fields' widget.

Used so the app never requires an Excel file to have exact, specific column
names/order: the user sees their actual column headers and assigns each one to
a field (or leaves it unmapped), with a best-effort auto-guess pre-filled.
"""
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QComboBox, QLabel, QScrollArea)

IGNORE = "— نگاشت نشود —"


class ColumnMappingWidget(QWidget):
    def __init__(self, field_defs, parent=None):
        super().__init__(parent)
        self.field_defs = field_defs
        self.combos = {}
        self.headers = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        self.form = QFormLayout(inner)
        for key, label, _kw in field_defs:
            combo = QComboBox()
            combo.addItem(IGNORE)
            self.combos[key] = combo
            self.form.addRow(label + ":", combo)
        scroll.setWidget(inner)
        outer.addWidget(scroll)

    def set_headers(self, headers, mapping=None):
        """headers: list of column header strings from the Excel file.
        mapping: optional {field_key: column_index_or_None} to pre-select."""
        self.headers = headers
        for key, combo in self.combos.items():
            combo.blockSignals(True)
            combo.clear()
            combo.addItem(IGNORE)
            combo.addItems([f"{i + 1}. {h}" for i, h in enumerate(headers)])
            idx = (mapping or {}).get(key)
            combo.setCurrentIndex(idx + 1 if idx is not None else 0)
            combo.blockSignals(False)

    def get_mapping(self):
        """Returns {field_key: column_index_or_None} from the current combo selections."""
        result = {}
        for key, combo in self.combos.items():
            i = combo.currentIndex()
            result[key] = (i - 1) if i > 0 else None
        return result
