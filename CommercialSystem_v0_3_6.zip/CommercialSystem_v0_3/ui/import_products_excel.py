from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTableWidget,
                               QTableWidgetItem, QFileDialog, QMessageBox, QTabWidget, QComboBox, QWidget)
from services.excel_import import (read_raw, guess_mapping, apply_mapping, import_products,
                                   make_sample_products_excel, PRODUCT_FIELD_DEFS)
from ui.excel_mapping import ColumnMappingWidget


class ProductExcelImportDialog(QDialog):
    def __init__(self, session_factory, parent=None):
        super().__init__(parent)
        self.session_factory = session_factory
        self.headers, self.data_rows = [], []
        self.setWindowTitle("ورود محصولات از Excel")
        self.resize(1100, 680)
        l = QVBoxLayout(self)
        self.info = QLabel(
            "فایل Excel محصولات خود را با هر ستون‌بندی که دارید انتخاب کنید — لازم نیست نام ستون‌ها "
            "دقیقاً مطابق برنامه باشد. برنامه حدس اولیه می‌زند؛ در تب «تطبیق ستون‌ها» می‌توانید هر "
            "ستون را به فیلد درست وصل کنید یا نگاشت‌نشده رها کنید.")
        self.info.setWordWrap(True)
        l.addWidget(self.info)

        top = QHBoxLayout()
        b = QPushButton("📤 انتخاب فایل Excel")
        b.clicked.connect(self.open_file)
        top.addWidget(b)
        top.addWidget(QLabel("شیت:"))
        self.sheet_combo = QComboBox()
        self.sheet_combo.currentIndexChanged.connect(self.change_sheet)
        top.addWidget(self.sheet_combo)
        sample_btn = QPushButton("⬇️ دانلود نمونه فایل Excel")
        sample_btn.clicked.connect(self.download_sample)
        top.addWidget(sample_btn)
        self.import_btn = QPushButton("✅ ثبت در بانک اطلاعاتی")
        self.import_btn.setEnabled(False)
        self.import_btn.clicked.connect(self.do_import)
        top.addWidget(self.import_btn)
        l.addLayout(top)

        self.tabs = QTabWidget()
        l.addWidget(self.tabs)

        preview_tab = QWidget()
        pl = QVBoxLayout(preview_tab)
        self.table = QTableWidget(0, 0)
        pl.addWidget(self.table)
        self.tabs.addTab(preview_tab, "پیش‌نمایش")

        self.mapper = ColumnMappingWidget(PRODUCT_FIELD_DEFS)
        self.tabs.addTab(self.mapper, "🔗 تطبیق ستون‌ها")

        self._path = None

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب Excel", "", "Excel (*.xlsx *.xlsm)")
        if not path:
            return
        self._path = path
        try:
            sheets, headers, rows = read_raw(path)
            self.sheet_combo.blockSignals(True)
            self.sheet_combo.clear()
            self.sheet_combo.addItems(sheets)
            self.sheet_combo.blockSignals(False)
            self._load(headers, rows)
        except Exception as e:
            QMessageBox.critical(self, "خطا", str(e))

    def change_sheet(self):
        if not self._path or not self.sheet_combo.currentText():
            return
        try:
            _, headers, rows = read_raw(self._path, sheet=self.sheet_combo.currentText())
            self._load(headers, rows)
        except Exception as e:
            QMessageBox.critical(self, "خطا", str(e))

    def _load(self, headers, rows):
        self.headers, self.data_rows = headers, rows
        guess = guess_mapping(headers, PRODUCT_FIELD_DEFS)
        self.mapper.set_headers(headers, guess)
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(min(len(rows), 300))
        for r, vals in enumerate(rows[:300]):
            for c, v in enumerate(vals):
                self.table.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
        self.info.setText(f"{len(rows)} رکورد در این شیت پیدا شد. تب «تطبیق ستون‌ها» را بررسی کنید و سپس ثبت کنید.")
        self.import_btn.setEnabled(bool(rows))

    def download_sample(self):
        out, _ = QFileDialog.getSaveFileName(self, "ذخیره نمونه فایل", "نمونه_محصولات.xlsx",
                                             "Excel (*.xlsx)")
        if not out:
            return
        make_sample_products_excel(out)
        QMessageBox.information(self, "ذخیره شد", out)

    def do_import(self):
        mapping = self.mapper.get_mapping()
        if mapping.get("name_fa") is None and mapping.get("name_en") is None:
            QMessageBox.warning(self, "توجه",
                                "لطفاً در تب «تطبیق ستون‌ها» حداقل یکی از «نام محصول» یا «نام انگلیسی» را وصل کنید.")
            self.tabs.setCurrentWidget(self.mapper)
            return
        rows = apply_mapping(self.data_rows, mapping)
        s = self.session_factory()
        try:
            a, u, sk = import_products(s, rows)
            QMessageBox.information(self, "نتیجه", f"افزوده شد: {a}\nبه‌روزرسانی شد: {u}\nرد شد: {sk}")
            self.accept()
        except Exception as e:
            s.rollback()
            QMessageBox.critical(self, "خطا", str(e))
        finally:
            s.close()
