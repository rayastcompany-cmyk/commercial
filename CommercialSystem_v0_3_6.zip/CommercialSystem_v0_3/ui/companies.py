from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTableWidget,
                               QTableWidgetItem, QDialog, QFormLayout, QTextEdit, QCheckBox, QComboBox,
                               QMessageBox, QTabWidget, QLabel, QGridLayout, QSplitter, QAbstractItemView,
                               QHeaderView)
from PySide6.QtCore import Qt
from ui.theme import style_table
from models import ROLES, POSITIONS
from ui.import_excel import ExcelImportDialog
from ui.common import warn, confirm

FIELDS = [("نام شرکت (فارسی) *", "company_name_fa"), ("نام انگلیسی", "company_name_en"),
          ("کشور", "country"), ("شهر", "city"), ("تلفن", "phone"), ("موبایل", "mobile"),
          ("ایمیل", "email"), ("وب‌سایت", "website"), ("واتساپ", "whatsapp"), ("لینکدین", "linkedin"),
          ("نوع فعالیت", "company_type"), ("شناسه مالیاتی", "tax_id"), ("شماره ثبت", "registration_no")]


class ContactDialog(QDialog):
    def __init__(self, parent=None, data=None):
        super().__init__(parent)
        self.setWindowTitle("شخص مرتبط")
        self.resize(420, 380)
        form = QFormLayout(self)
        self.fields = {}
        for label, key in [("نام", "first_name"), ("نام خانوادگی", "last_name"), ("تلفن", "phone"),
                           ("موبایل", "mobile"), ("ایمیل", "email"), ("واتساپ", "whatsapp"),
                           ("لینکدین", "linkedin")]:
            e = QLineEdit()
            self.fields[key] = e
            form.addRow(label + ":", e)
        self.position = QComboBox()
        self.position.addItems(POSITIONS)
        form.addRow("سمت:", self.position)
        self.decision = QCheckBox("تصمیم‌گیرنده اصلی")
        form.addRow(self.decision)
        self.notes = QTextEdit()
        self.notes.setFixedHeight(60)
        form.addRow("یادداشت:", self.notes)
        if data:
            for k, e in self.fields.items():
                e.setText(getattr(data, k) or "")
            if data.position in POSITIONS:
                self.position.setCurrentText(data.position)
            self.decision.setChecked(bool(data.is_decision_maker))
            self.notes.setPlainText(data.notes or "")
        btn = QPushButton("ذخیره")
        btn.clicked.connect(self.accept)
        form.addRow(btn)

    def values(self):
        d = {k: e.text().strip() for k, e in self.fields.items()}
        d["position"] = self.position.currentText()
        d["is_decision_maker"] = self.decision.isChecked()
        d["notes"] = self.notes.toPlainText().strip()
        return d


class CompaniesPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.user = user
        self.current_id = None
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("جست‌وجوی شرکت (نام، کشور، ایمیل)...")
        self.search.textChanged.connect(self.load_list)
        top.addWidget(self.search)
        self.role_filter = QComboBox()
        self.role_filter.addItems(["همه نقش‌ها"] + ROLES)
        self.role_filter.currentIndexChanged.connect(self.load_list)
        top.addWidget(self.role_filter)
        new_btn = QPushButton("➕ شرکت جدید")
        new_btn.clicked.connect(self.new_company)
        top.addWidget(new_btn)
        imp_btn = QPushButton("📥 ورود از Excel")
        imp_btn.clicked.connect(self.import_excel)
        top.addWidget(imp_btn)
        root.addLayout(top)

        split = QSplitter()
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["شناسه", "نام شرکت", "کشور", "نقش‌ها", "تلفن"])
        style_table(self.table)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.on_select)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        split.addWidget(self.table)

        detail = QWidget()
        dl = QVBoxLayout(detail)
        self.tabs = QTabWidget()
        dl.addWidget(self.tabs)

        info_tab = QWidget()
        il = QVBoxLayout(info_tab)
        self.fields = {}
        grid = QGridLayout()
        for i, (label, key) in enumerate(FIELDS):
            grid.addWidget(QLabel(label + ":"), i // 2, (i % 2) * 2)
            e = QLineEdit()
            self.fields[key] = e
            grid.addWidget(e, i // 2, (i % 2) * 2 + 1)
        il.addLayout(grid)
        il.addWidget(QLabel("نقش‌ها:"))
        role_row = QHBoxLayout()
        self.role_boxes = {}
        for r in ROLES:
            cb = QCheckBox(r)
            self.role_boxes[r] = cb
            role_row.addWidget(cb)
        role_wrap = QWidget()
        role_wrap.setLayout(role_row)
        il.addWidget(role_wrap)
        il.addWidget(QLabel("محصولات (متن آزاد):"))
        self.products_text = QTextEdit(); self.products_text.setFixedHeight(45)
        il.addWidget(self.products_text)
        il.addWidget(QLabel("روابط عمومی:"))
        self.public_relation = QTextEdit(); self.public_relation.setFixedHeight(45)
        il.addWidget(self.public_relation)
        il.addWidget(QLabel("توضیحات:"))
        self.description = QTextEdit(); self.description.setFixedHeight(45)
        il.addWidget(self.description)
        btn_row = QHBoxLayout()
        save_btn = QPushButton("💾 ذخیره اطلاعات شرکت")
        save_btn.clicked.connect(self.save_company)
        btn_row.addWidget(save_btn)
        del_btn = QPushButton("🗑 حذف شرکت")
        del_btn.clicked.connect(self.delete_company)
        btn_row.addWidget(del_btn)
        il.addLayout(btn_row)
        il.addStretch()
        self.tabs.addTab(info_tab, "اطلاعات شرکت")

        contacts_tab = QWidget()
        cl = QVBoxLayout(contacts_tab)
        crow = QHBoxLayout()
        cadd = QPushButton("➕ شخص جدید")
        cadd.clicked.connect(self.add_contact)
        crow.addWidget(cadd)
        cedit = QPushButton("✏️ ویرایش")
        cedit.clicked.connect(self.edit_contact)
        crow.addWidget(cedit)
        cdel = QPushButton("🗑 حذف")
        cdel.clicked.connect(self.delete_contact)
        crow.addWidget(cdel)
        cl.addLayout(crow)
        self.contacts_table = QTableWidget(0, 6)
        self.contacts_table.setHorizontalHeaderLabels(["شناسه", "نام", "سمت", "تلفن", "ایمیل", "تصمیم‌گیرنده"])
        style_table(self.contacts_table)
        self.contacts_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.contacts_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        cl.addWidget(self.contacts_table)
        self.tabs.addTab(contacts_tab, "اشخاص مرتبط")

        prod_tab = QWidget()
        pl = QVBoxLayout(prod_tab)
        prow = QHBoxLayout()
        self.product_pick = QComboBox()
        prow.addWidget(self.product_pick, 3)
        self.relation_pick = QComboBox()
        self.relation_pick.addItems(["Supplies", "Buys", "Produces", "Interested"])
        prow.addWidget(self.relation_pick, 1)
        padd = QPushButton("➕ افزودن")
        padd.clicked.connect(self.add_company_product)
        prow.addWidget(padd)
        pl.addLayout(prow)
        self.cp_table = QTableWidget(0, 3)
        self.cp_table.setHorizontalHeaderLabels(["شناسه", "محصول", "نوع رابطه"])
        style_table(self.cp_table)
        self.cp_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        pl.addWidget(self.cp_table)
        pdel = QPushButton("🗑 حذف رابطه انتخاب‌شده")
        pdel.clicked.connect(self.delete_company_product)
        pl.addWidget(pdel)
        self.tabs.addTab(prod_tab, "محصولات مرتبط")

        split.addWidget(detail)
        self.table.setMinimumWidth(380)
        split.setStretchFactor(0, 4)
        split.setStretchFactor(1, 6)
        root.addWidget(split)

        self.load_list()
        self.clear_form()

    # ---------------------------------------------------------------- list
    def load_list(self):
        from models import Company
        s = self.session_factory()
        try:
            q = self.search.text().strip()
            query = s.query(Company)
            if q:
                query = query.filter(
                    Company.company_name_fa.contains(q) | Company.company_name_en.contains(q) |
                    Company.country.contains(q) | Company.email.contains(q))
            rows = query.order_by(Company.id.desc()).all()
            rf = self.role_filter.currentText()
            if rf != "همه نقش‌ها":
                rows = [c for c in rows if rf in c.role_list]
            self.table.setRowCount(len(rows))
            for r, c in enumerate(rows):
                vals = [c.id, c.company_name_fa, c.country or "", ", ".join(c.role_list), c.phone or ""]
                for col, v in enumerate(vals):
                    self.table.setItem(r, col, QTableWidgetItem(str(v)))
        finally:
            s.close()

    def on_select(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        cid = int(self.table.item(rows[0].row(), 0).text())
        self.load_company(cid)

    # ---------------------------------------------------------------- form
    def clear_form(self):
        self.current_id = None
        for e in self.fields.values():
            e.setText("")
        for cb in self.role_boxes.values():
            cb.setChecked(False)
        self.products_text.setPlainText("")
        self.public_relation.setPlainText("")
        self.description.setPlainText("")
        self.contacts_table.setRowCount(0)
        self.cp_table.setRowCount(0)

    def new_company(self):
        self.table.clearSelection()
        self.clear_form()
        self.tabs.setCurrentIndex(0)

    def load_company(self, cid):
        from models import Company
        s = self.session_factory()
        try:
            c = s.get(Company, cid)
            if not c:
                return
            self.current_id = cid
            for key, e in self.fields.items():
                e.setText(getattr(c, key) or "")
            roles = c.role_list
            for r, cb in self.role_boxes.items():
                cb.setChecked(r in roles)
            self.products_text.setPlainText(c.products_text or "")
            self.public_relation.setPlainText(c.public_relation or "")
            self.description.setPlainText(c.description or "")
            self.reload_contacts(s, c)
            self.reload_company_products(s, c)
        finally:
            s.close()

    def reload_contacts(self, s, c):
        self.contacts_table.setRowCount(len(c.contacts))
        for r, ct in enumerate(c.contacts):
            vals = [ct.id, ct.full_name, ct.position or "", ct.phone or ct.mobile or "", ct.email or "",
                    "بله" if ct.is_decision_maker else ""]
            for col, v in enumerate(vals):
                self.contacts_table.setItem(r, col, QTableWidgetItem(str(v)))

    def reload_company_products(self, s, c):
        from models import Product
        self.product_pick.clear()
        self._prod_ids = []
        for p in s.query(Product).order_by(Product.name_fa).all():
            self.product_pick.addItem(p.name_en or p.name_fa)
            self._prod_ids.append(p.id)
        self.cp_table.setRowCount(len(c.products))
        for r, cp in enumerate(c.products):
            vals = [cp.id, (cp.product.name_en or cp.product.name_fa) if cp.product else "?", cp.relation or ""]
            for col, v in enumerate(vals):
                self.cp_table.setItem(r, col, QTableWidgetItem(str(v)))

    def save_company(self):
        from models import Company, CompanyRole
        name = self.fields["company_name_fa"].text().strip()
        if not name:
            warn(self, "خطا", "نام شرکت الزامی است.")
            return
        s = self.session_factory()
        try:
            if self.current_id:
                c = s.get(Company, self.current_id)
            else:
                c = Company(company_name_fa=name)
                s.add(c)
            for key, e in self.fields.items():
                setattr(c, key, e.text().strip())
            c.products_text = self.products_text.toPlainText().strip()
            c.public_relation = self.public_relation.toPlainText().strip()
            c.description = self.description.toPlainText().strip()
            s.flush()
            selected = {r for r, cb in self.role_boxes.items() if cb.isChecked()}
            existing = {cr.role: cr for cr in c.roles}
            for r in selected - existing.keys():
                s.add(CompanyRole(company_id=c.id, role=r))
            for r in existing.keys() - selected:
                s.delete(existing[r])
            s.commit()
            self.current_id = c.id
        finally:
            s.close()
        self.load_list()
        self.load_company(self.current_id)

    def delete_company(self):
        if not self.current_id or not confirm(self, "حذف", "شرکت و همه اشخاص/روابط مرتبط حذف شود؟"):
            return
        from models import Company
        s = self.session_factory()
        try:
            c = s.get(Company, self.current_id)
            if c:
                s.delete(c)
                s.commit()
        finally:
            s.close()
        self.load_list()
        self.new_company()

    # ---------------------------------------------------------------- contacts
    def add_contact(self):
        if not self.current_id:
            warn(self, "توجه", "ابتدا شرکت را ذخیره کنید.")
            return
        dlg = ContactDialog(self)
        if dlg.exec():
            from models import Contact
            s = self.session_factory()
            try:
                s.add(Contact(company_id=self.current_id, **dlg.values()))
                s.commit()
            finally:
                s.close()
            self.load_company(self.current_id)

    def _selected_contact_id(self):
        rows = self.contacts_table.selectionModel().selectedRows()
        return int(self.contacts_table.item(rows[0].row(), 0).text()) if rows else None

    def edit_contact(self):
        cid = self._selected_contact_id()
        if not cid:
            return
        from models import Contact
        s = self.session_factory()
        try:
            ct = s.get(Contact, cid)
            dlg = ContactDialog(self, ct)
            if dlg.exec():
                for k, v in dlg.values().items():
                    setattr(ct, k, v)
                s.commit()
        finally:
            s.close()
        self.load_company(self.current_id)

    def delete_contact(self):
        cid = self._selected_contact_id()
        if not cid or not confirm(self, "حذف", "این شخص حذف شود؟"):
            return
        from models import Contact
        s = self.session_factory()
        try:
            ct = s.get(Contact, cid)
            if ct:
                s.delete(ct)
                s.commit()
        finally:
            s.close()
        self.load_company(self.current_id)

    # ---------------------------------------------------------------- related products
    def add_company_product(self):
        if not self.current_id or not getattr(self, "_prod_ids", None):
            warn(self, "توجه", "ابتدا شرکت را ذخیره کنید و محصولی ثبت کنید.")
            return
        idx = self.product_pick.currentIndex()
        if idx < 0:
            return
        from models import CompanyProduct
        s = self.session_factory()
        try:
            s.add(CompanyProduct(company_id=self.current_id, product_id=self._prod_ids[idx],
                                 relation=self.relation_pick.currentText()))
            s.commit()
        finally:
            s.close()
        self.load_company(self.current_id)

    def delete_company_product(self):
        rows = self.cp_table.selectionModel().selectedRows()
        if not rows:
            return
        cpid = int(self.cp_table.item(rows[0].row(), 0).text())
        from models import CompanyProduct
        s = self.session_factory()
        try:
            cp = s.get(CompanyProduct, cpid)
            if cp:
                s.delete(cp)
                s.commit()
        finally:
            s.close()
        self.load_company(self.current_id)

    def import_excel(self):
        dlg = ExcelImportDialog(self.session_factory, self)
        dlg.exec()
        self.load_list()
