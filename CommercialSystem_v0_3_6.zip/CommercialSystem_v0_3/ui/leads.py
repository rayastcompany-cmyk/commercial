import datetime as dt
from ui.theme import style_table

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTableWidget,
                               QTableWidgetItem, QComboBox, QLabel, QGridLayout, QTextEdit, QDateEdit,
                               QSplitter, QAbstractItemView, QHeaderView)
from PySide6.QtCore import QDate
from models import LEAD_STATUS
from ui.common import warn, confirm

STATUS_COLORS = {"New": "#DBEAFE", "Contacted": "#E0E7FF", "Negotiating": "#FEF3C7", "Quotation": "#FDE68A",
                 "PI": "#FCD34D", "Contract": "#BBF7D0", "Won": "#86EFAC", "Lost": "#FCA5A5"}


class LeadsPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.user = user
        self.current_id = None
        root = QVBoxLayout(self)

        title = QLabel("🎯 لیدهای فروش — خریداران بالقوه")
        title.setProperty("cssClass", "h1")
        root.addWidget(title)
        subtitle = QLabel("این بخش برای پیگیری شرکت‌هایی است که می‌خواهید محصولات خودتان را به آن‌ها "
                          "بفروشید (نه تأمین‌کنندگان). هر لید در نهایت می‌تواند به یک PI با همین شرکت "
                          "به‌عنوان «خریدار» تبدیل شود.")
        subtitle.setProperty("cssClass", "muted")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        top = QHBoxLayout()
        self.status_filter = QComboBox()
        self.status_filter.addItems(["همه"] + LEAD_STATUS)
        self.status_filter.currentIndexChanged.connect(self.load_list)
        top.addWidget(QLabel("فیلتر وضعیت:"))
        top.addWidget(self.status_filter)
        new_btn = QPushButton("➕ خریدار بالقوه جدید")
        new_btn.clicked.connect(self.new_lead)
        top.addWidget(new_btn)
        top.addStretch()
        root.addLayout(top)

        split = QSplitter()
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["شناسه", "شرکت خریدار", "محصول پیشنهادی", "وضعیت", "اولویت", "پیگیری بعدی"])
        style_table(self.table)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.on_select)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        split.addWidget(self.table)

        form_w = QWidget()
        fl = QVBoxLayout(form_w)
        grid = QGridLayout()
        self.fields = {}
        field_defs = [("نام شرکت خریدار *", "company_name", "مثلاً: شرکت بازرگانی ... (مشتری بالقوه)"),
                     ("کشور خریدار", "country", ""),
                     ("شخص رابط در شرکت خریدار", "contact", ""),
                     ("محصولی که می‌خواهیم بفروشیم", "product", "مثلاً: HDPE F7000"),
                     ("این مشتری را از کجا پیدا کردیم؟", "source", "نمایشگاه / لینکدین / معرفی و ..."),
                     ("مسئول فروش ما", "sales_person", "")]
        for i, (label, key, ph) in enumerate(field_defs):
            grid.addWidget(QLabel(label + ":"), i // 2, (i % 2) * 2)
            e = QLineEdit()
            if ph:
                e.setPlaceholderText(ph)
            self.fields[key] = e
            grid.addWidget(e, i // 2, (i % 2) * 2 + 1)
        fl.addLayout(grid)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("وضعیت:"))
        self.status = QComboBox(); self.status.addItems(LEAD_STATUS)
        row2.addWidget(self.status)
        row2.addWidget(QLabel("اولویت:"))
        self.priority = QComboBox(); self.priority.addItems(["Low", "Medium", "High"])
        row2.addWidget(self.priority)
        fl.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("پیگیری بعدی:"))
        self.next_fu = QDateEdit(); self.next_fu.setCalendarPopup(True); self.next_fu.setDate(QDate.currentDate())
        row3.addWidget(self.next_fu)
        fl.addLayout(row3)

        fl.addWidget(QLabel("یادداشت:"))
        self.notes = QTextEdit(); self.notes.setFixedHeight(80)
        fl.addWidget(self.notes)

        btn_row = QHBoxLayout()
        save_btn = QPushButton("💾 ذخیره")
        save_btn.clicked.connect(self.save_lead)
        btn_row.addWidget(save_btn)
        del_btn = QPushButton("🗑 حذف")
        del_btn.clicked.connect(self.delete_lead)
        btn_row.addWidget(del_btn)
        fl.addLayout(btn_row)
        fl.addStretch()

        split.addWidget(form_w)
        self.table.setMinimumWidth(380)
        split.setStretchFactor(0, 5)
        split.setStretchFactor(1, 5)
        root.addWidget(split)

        self.load_list()
        self.clear_form()

    def load_list(self):
        from models import Lead
        s = self.session_factory()
        try:
            query = s.query(Lead)
            f = self.status_filter.currentText()
            if f != "همه":
                query = query.filter(Lead.status == f)
            rows = query.order_by(Lead.id.desc()).all()
            self.table.setRowCount(len(rows))
            for r, ld in enumerate(rows):
                vals = [ld.id, ld.company_name or "", ld.product or "", ld.status or "", ld.priority or "",
                       ld.next_followup or ""]
                for col, v in enumerate(vals):
                    self.table.setItem(r, col, QTableWidgetItem(str(v)))
        finally:
            s.close()

    def on_select(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        self.load_lead(int(self.table.item(rows[0].row(), 0).text()))

    def clear_form(self):
        self.current_id = None
        for e in self.fields.values():
            e.setText("")
        self.status.setCurrentIndex(0)
        self.priority.setCurrentText("Medium")
        self.next_fu.setDate(QDate.currentDate())
        self.notes.setPlainText("")

    def new_lead(self):
        self.table.clearSelection()
        self.clear_form()

    def load_lead(self, lid):
        from models import Lead
        s = self.session_factory()
        try:
            ld = s.get(Lead, lid)
            if not ld:
                return
            self.current_id = lid
            for key, e in self.fields.items():
                e.setText(getattr(ld, key) or "")
            self.status.setCurrentText(ld.status or "New")
            self.priority.setCurrentText(ld.priority or "Medium")
            d = QDate.fromString(ld.next_followup or "", "yyyy-MM-dd")
            self.next_fu.setDate(d if d.isValid() else QDate.currentDate())
            self.notes.setPlainText(ld.notes or "")
        finally:
            s.close()

    def save_lead(self):
        name = self.fields["company_name"].text().strip()
        if not name:
            warn(self, "خطا", "نام شرکت خریدار الزامی است.")
            return
        from models import Lead
        s = self.session_factory()
        try:
            if self.current_id:
                ld = s.get(Lead, self.current_id)
            else:
                ld = Lead(date_added=dt.date.today().isoformat())
                s.add(ld)
            for key, e in self.fields.items():
                setattr(ld, key, e.text().strip())
            ld.status = self.status.currentText()
            ld.priority = self.priority.currentText()
            ld.next_followup = self.next_fu.date().toString("yyyy-MM-dd")
            ld.notes = self.notes.toPlainText().strip()
            s.commit()
            self.current_id = ld.id
        finally:
            s.close()
        self.load_list()

    def delete_lead(self):
        if not self.current_id or not confirm(self, "حذف", "این لید حذف شود؟"):
            return
        from models import Lead
        s = self.session_factory()
        try:
            ld = s.get(Lead, self.current_id)
            if ld:
                s.delete(ld)
                s.commit()
        finally:
            s.close()
        self.load_list()
        self.clear_form()
