from pathlib import Path

from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QFileDialog, QListWidget
from database import BASE_DIR
from services.backup import backup_database, list_backups
from ui.common import info, warn


class ReportsPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        root = QVBoxLayout(self)

        root.addWidget(QLabel("<b>📈 گزارش‌ها و پشتیبان‌گیری</b>"))

        xlsx_btn = QPushButton("📊 خروجی Excel از همه اطلاعات")
        xlsx_btn.clicked.connect(self.export_excel)
        root.addWidget(xlsx_btn)

        backup_btn = QPushButton("💾 ساخت پشتیبان (دیتابیس + تصاویر)")
        backup_btn.clicked.connect(self.make_backup)
        root.addWidget(backup_btn)

        root.addWidget(QLabel("پشتیبان‌های قبلی:"))
        self.backup_list = QListWidget()
        root.addWidget(self.backup_list)
        self.refresh_backups()

        root.addStretch()

    def refresh_backups(self):
        self.backup_list.clear()
        for b in list_backups():
            self.backup_list.addItem(b.name)

    def make_backup(self):
        path = backup_database()
        if path:
            info(self, "پشتیبان‌گیری", f"پشتیبان ایجاد شد:\n{path}")
            self.refresh_backups()
        else:
            warn(self, "خطا", "دیتابیس یافت نشد.")

    def export_excel(self):
        try:
            import pandas as pd
        except ImportError:
            warn(self, "خطا", "کتابخانه pandas نصب نیست. با: pip install pandas نصب کنید.")
            return
        out, _ = QFileDialog.getSaveFileName(self, "ذخیره Excel", "trade_export.xlsx", "Excel (*.xlsx)")
        if not out:
            return
        from database import engine
        import sqlite3
        tables = {"Companies": "companies", "Contacts": "contacts", "CompanyRoles": "company_roles",
                  "Products": "products", "Specs": "product_specifications", "Leads": "leads",
                  "PIs": "pis", "PI_Items": "pi_items", "Payments": "payments"}
        with pd.ExcelWriter(out, engine="openpyxl") as xw:
            for sheet, table in tables.items():
                try:
                    df = pd.read_sql(f"SELECT * FROM {table}", engine)
                except Exception:
                    df = pd.DataFrame()
                df.to_excel(xw, sheet_name=sheet, index=False)
        info(self, "خروجی گرفته شد", out)
