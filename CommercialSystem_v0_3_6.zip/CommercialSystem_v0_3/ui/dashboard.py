from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
                               QStackedWidget, QMessageBox, QGridLayout, QFrame, QTableWidget,
                               QTableWidgetItem, QScrollArea)
from PySide6.QtCore import Qt
from ui.mycompany import MyCompanyPage
from ui.companies import CompaniesPage
from ui.products import ProductsPage
from ui.leads import LeadsPage
from ui.pi import PIPage
from ui.payments import PaymentsPage
from ui.catalog import CatalogPage
from ui.users import UsersPage
from ui.reports import ReportsPage
from services.backup import backup_database
from ui.theme import GOLD


class StatCard(QFrame):
    def __init__(self, title, value, icon="", alt=False):
        super().__init__()
        self.setObjectName("statCardAlt" if alt else "statCard")
        self.setMinimumHeight(84)
        l = QVBoxLayout(self)
        l.setContentsMargins(18, 14, 18, 14)
        top = QHBoxLayout()
        v = QLabel(str(value))
        v.setStyleSheet("font-size:24px;font-weight:800;color:white;")
        top.addWidget(v)
        top.addStretch()
        if icon:
            ic = QLabel(icon)
            ic.setStyleSheet("font-size:22px;")
            top.addWidget(ic)
        l.addLayout(top)
        t = QLabel(title)
        t.setStyleSheet(f"color:{GOLD};font-weight:600;font-size:12px;")
        l.addWidget(t)
        self.value_label = v


class HomePage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        inner = QWidget()
        root = QVBoxLayout(inner)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        welcome = QLabel(f"خوش آمدید، {user.full_name or user.username} 👋")
        welcome.setProperty("cssClass", "h1")
        root.addWidget(welcome)
        sub = QLabel("نمای کلی وضعیت شرکت‌ها، لیدها و PIهای شما")
        sub.setProperty("cssClass", "muted")
        root.addWidget(sub)

        self.cards_row = QHBoxLayout()
        self.cards_row.setSpacing(14)
        root.addLayout(self.cards_row)

        fu_title = QLabel("⏰ پیگیری‌های امروز و عقب‌افتاده")
        fu_title.setProperty("cssClass", "h2")
        root.addWidget(fu_title)
        self.fu_table = QTableWidget(0, 4)
        self.fu_table.setHorizontalHeaderLabels(["شرکت خریدار", "محصول پیشنهادی", "وضعیت", "تاریخ پیگیری"])
        self.fu_table.setAlternatingRowColors(True)
        self.fu_table.verticalHeader().setVisible(False)
        root.addWidget(self.fu_table)

        pi_title = QLabel("🧾 آخرین PIها")
        pi_title.setProperty("cssClass", "h2")
        root.addWidget(pi_title)
        self.pi_table = QTableWidget(0, 4)
        self.pi_table.setHorizontalHeaderLabels(["شماره PI", "خریدار", "مبلغ", "وضعیت"])
        self.pi_table.setAlternatingRowColors(True)
        self.pi_table.verticalHeader().setVisible(False)
        root.addWidget(self.pi_table)
        root.addStretch()

        scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.addWidget(scroll)
        self.refresh()

    def showEvent(self, e):
        super().showEvent(e)
        self.refresh()

    def refresh(self):
        import datetime as dt
        from models import Company, Product, Lead, PI, Payment
        while self.cards_row.count():
            item = self.cards_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        s = self.session_factory()
        try:
            n_co = s.query(Company).count()
            n_pr = s.query(Product).count()
            n_lead = s.query(Lead).filter(~Lead.status.in_(["Won", "Lost"])).count()
            n_pi = s.query(PI).count()
            stats = [("شرکت‌ها", n_co, "🌍"), ("محصولات", n_pr, "📦"), ("لیدهای باز", n_lead, "🎯"),
                    ("PI صادرشده", n_pi, "🧾")]
            for i, (title, val, icon) in enumerate(stats):
                self.cards_row.addWidget(StatCard(title, val, icon, alt=(i % 2 == 1)))

            today = dt.date.today().isoformat()
            leads = (s.query(Lead).filter(Lead.next_followup != "", Lead.next_followup <= today,
                                          ~Lead.status.in_(["Won", "Lost"])).order_by(Lead.next_followup).all())
            self.fu_table.setRowCount(len(leads))
            for r, ld in enumerate(leads):
                for c, v in enumerate([ld.company_name or "", ld.product or "", ld.status or "",
                                       ld.next_followup or ""]):
                    self.fu_table.setItem(r, c, QTableWidgetItem(v))

            pis = s.query(PI).order_by(PI.id.desc()).limit(10).all()
            self.pi_table.setRowCount(len(pis))
            for r, p in enumerate(pis):
                vals = [p.pi_no, p.buyer.company_name_fa if p.buyer else "",
                       f"{p.currency} {p.total:,.2f}" if p.total else "", p.status or ""]
                for c, v in enumerate(vals):
                    self.pi_table.setItem(r, c, QTableWidgetItem(str(v)))
        finally:
            s.close()


class Dashboard(QMainWindow):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.user = user
        self.setWindowTitle(f"سیستم مدیریت بازرگانی — {user.full_name or user.username} ({user.role})")
        self.resize(1350, 820)

        root = QWidget()
        self.setCentralWidget(root)
        main = QHBoxLayout(root)
        main.setContentsMargins(0, 0, 0, 0)
        main.setSpacing(0)

        sidebar_wrap = QWidget()
        sidebar_wrap.setObjectName("sidebar")
        sidebar_wrap.setFixedWidth(230)
        sidebar = QVBoxLayout(sidebar_wrap)
        sidebar.setContentsMargins(0, 0, 0, 10)
        sidebar.setSpacing(2)

        title = QLabel("🏢 بازرگانی")
        title.setObjectName("sidebarTitle")
        title.setAlignment(Qt.AlignCenter)
        sidebar.addWidget(title)

        self.stack = QStackedWidget()
        self.pages = {
            "home": HomePage(session_factory, user),
            "mycompany": MyCompanyPage(session_factory, user),
            "companies": CompaniesPage(session_factory, user),
            "products": ProductsPage(session_factory, user),
            "leads": LeadsPage(session_factory, user),
            "pi": PIPage(session_factory, user),
            "payments": PaymentsPage(session_factory, user),
            "catalog": CatalogPage(session_factory, user),
            "reports": ReportsPage(session_factory, user),
            "users": UsersPage(session_factory, user),
        }
        for page in self.pages.values():
            self.stack.addWidget(page)

        nav_items = [("📊 داشبورد", "home"), ("🏢 شرکت من", "mycompany"), ("🌍 شرکت‌ها", "companies"),
                    ("📦 محصولات", "products"), ("🎯 لیدهای فروش", "leads"), ("🧾 PI", "pi"),
                    ("💳 پرداخت‌ها", "payments"), ("📚 کاتالوگ", "catalog"), ("📈 گزارش‌ها", "reports")]
        if user.role == "Admin":
            nav_items.append(("👤 کاربران", "users"))
        self.nav_buttons = {}
        for text, key in nav_items:
            b = QPushButton(text)
            b.setObjectName("navBtn")
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda checked=False, k=key: self.show_page(k))
            self.nav_buttons[key] = b
            wrap = QHBoxLayout()
            wrap.setContentsMargins(10, 0, 10, 0)
            wrap.addWidget(b)
            hold = QWidget()
            hold.setLayout(wrap)
            sidebar.addWidget(hold)

        sidebar.addStretch()

        backup_btn = QPushButton("💾 پشتیبان‌گیری سریع")
        backup_btn.setObjectName("backupBtn")
        backup_btn.setCursor(Qt.PointingHandCursor)
        backup_btn.clicked.connect(self.do_backup)
        sidebar.addWidget(backup_btn)

        user_label = QLabel(f"👤 {user.username} — {user.role}")
        user_label.setObjectName("sidebarUser")
        sidebar.addWidget(user_label)

        main.addWidget(sidebar_wrap)
        main.addWidget(self.stack, 1)
        self.show_page("home")

    def show_page(self, key):
        page = self.pages[key]
        self.stack.setCurrentWidget(page)
        for k, b in self.nav_buttons.items():
            b.setObjectName("navBtnActive" if k == key else "navBtn")
            b.style().unpolish(b)
            b.style().polish(b)
        if hasattr(page, "reload_company_combos"):
            page.reload_company_combos()
        if hasattr(page, "reload_pis"):
            page.reload_pis()
        if hasattr(page, "load_list"):
            page.load_list()

    def do_backup(self):
        path = backup_database()
        if path:
            QMessageBox.information(self, "پشتیبان‌گیری", f"پشتیبان ایجاد شد:\n{path}")
        else:
            QMessageBox.warning(self, "خطا", "دیتابیس یافت نشد.")
