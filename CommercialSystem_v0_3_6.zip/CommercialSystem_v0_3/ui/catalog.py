import traceback
import datetime as dt

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
                               QPushButton, QLabel, QTextEdit, QLineEdit, QCheckBox, QAbstractItemView,
                               QMessageBox)
from PySide6.QtCore import Qt
from database import OUTPUT_DIR
from ui.common import warn, info
import services.pdf as pdf_svc
import services.docx_catalog as docx_svc


class CatalogPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        root = QVBoxLayout(self)
        root.addWidget(QLabel("<b>📚 Catalog Builder</b> — محصولات را انتخاب کنید و کاتالوگ را به‌صورت PDF "
                              "یا Word (قابل ویرایش) با نام و لوگوی شرکت خودتان بسازید."))

        self.product_list = QListWidget()
        self.product_list.setSelectionMode(QAbstractItemView.MultiSelection)
        root.addWidget(self.product_list)
        root.addWidget(QLabel("برای انتخاب چند محصول، کلید Ctrl را نگه دارید و کلیک کنید."))

        root.addWidget(QLabel("Tagline روی جلد:"))
        self.tagline = QLineEdit("Oil & Petrochemical Products")
        root.addWidget(self.tagline)
        root.addWidget(QLabel("About Us:"))
        self.about = QTextEdit(); self.about.setFixedHeight(50)
        root.addWidget(self.about)
        root.addWidget(QLabel("Trading Activities:"))
        self.trading = QTextEdit(); self.trading.setFixedHeight(50)
        root.addWidget(self.trading)
        root.addWidget(QLabel("Markets:"))
        self.markets = QTextEdit(); self.markets.setFixedHeight(40)
        root.addWidget(self.markets)
        self.show_price = QCheckBox("نمایش قیمت در کاتالوگ")
        root.addWidget(self.show_price)

        btn_row = QHBoxLayout()
        word_btn = QPushButton("📝 ساخت کاتالوگ Word (قابل ویرایش)")
        word_btn.clicked.connect(lambda: self.generate("docx"))
        btn_row.addWidget(word_btn)
        pdf_btn = QPushButton("📕 ساخت کاتالوگ PDF")
        pdf_btn.clicked.connect(lambda: self.generate("pdf"))
        btn_row.addWidget(pdf_btn)
        root.addLayout(btn_row)

        self.result_label = QLabel("")
        self.result_label.setStyleSheet("color:green;")
        root.addWidget(self.result_label)

        self.reload_products()

    def showEvent(self, e):
        super().showEvent(e)
        self.reload_products()

    def reload_products(self):
        from models import Product
        s = self.session_factory()
        try:
            products = s.query(Product).order_by(Product.name_fa).all()
            self._ids = [p.id for p in products]
            self.product_list.clear()
            for p in products:
                self.product_list.addItem(QListWidgetItem(p.name_en or p.name_fa))
        finally:
            s.close()

    def generate(self, fmt):
        rows = self.product_list.selectedIndexes()
        if not rows:
            warn(self, "توجه", "حداقل یک محصول انتخاب کنید (برای انتخاب چند محصول، کلید Ctrl را نگه دارید).")
            return
        ids = [self._ids[i.row()] for i in rows if i.row() < len(self._ids)]
        from models import Product, MyCompany
        s = self.session_factory()
        try:
            products = [p for p in (s.get(Product, i) for i in ids) if p is not None]
            if not products:
                warn(self, "توجه", "محصولات انتخاب‌شده دیگر در بانک اطلاعاتی موجود نیستند. "
                                   "لطفاً فهرست را دوباره باز کنید و انتخاب کنید.")
                return
            me = s.get(MyCompany, 1)
            extra = (self.tagline.text().strip(), self.about.toPlainText().strip(),
                    self.markets.toPlainText().strip(), self.trading.toPlainText().strip(),
                    self.show_price.isChecked())
            if fmt == "docx":
                out = OUTPUT_DIR / f"Catalog_{dt.date.today().isoformat()}.docx"
                docx_svc.build_catalog_docx(products, me, out, *extra)
            else:
                out = OUTPUT_DIR / f"Catalog_{dt.date.today().isoformat()}.pdf"
                pdf_svc.build_catalog(products, me, out, *extra)
        except Exception as e:
            s.rollback()
            detail = traceback.format_exc()
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Critical)
            box.setWindowTitle("خطا در ساخت کاتالوگ")
            box.setText(f"ساخت کاتالوگ با خطا مواجه شد:\n{e}")
            box.setDetailedText(detail)
            box.exec()
            return
        finally:
            s.close()
        self.result_label.setText(f"ذخیره شد: {out}")
        info(self, "کاتالوگ صادر شد", str(out))
