from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTableWidget,
                               QTableWidgetItem, QComboBox, QLabel, QCheckBox, QAbstractItemView, QHeaderView)
from ui.common import warn, confirm, info
from ui.theme import style_table

ROLE_OPTIONS = ["Admin", "Sales", "Viewer"]


class UsersPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.user = user
        self.current_id = None
        root = QVBoxLayout(self)

        if user.role != "Admin":
            root.addWidget(QLabel("⛔ فقط مدیر سیستم (Admin) به این بخش دسترسی دارد."))
            return

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["شناسه", "نام کاربری", "نقش", "فعال"])
        style_table(self.table)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self.on_select)
        root.addWidget(self.table)

        form = QHBoxLayout()
        self.username = QLineEdit(); self.username.setPlaceholderText("نام کاربری")
        form.addWidget(self.username)
        self.full_name = QLineEdit(); self.full_name.setPlaceholderText("نام کامل")
        form.addWidget(self.full_name)
        self.password = QLineEdit(); self.password.setPlaceholderText("رمز عبور جدید (برای تغییر)")
        self.password.setEchoMode(QLineEdit.Password)
        form.addWidget(self.password)
        self.role = QComboBox(); self.role.addItems(ROLE_OPTIONS)
        form.addWidget(self.role)
        self.active = QCheckBox("فعال"); self.active.setChecked(True)
        form.addWidget(self.active)
        root.addLayout(form)

        btn_row = QHBoxLayout()
        new_btn = QPushButton("➕ کاربر جدید")
        new_btn.clicked.connect(self.clear_form)
        btn_row.addWidget(new_btn)
        save_btn = QPushButton("💾 ذخیره")
        save_btn.clicked.connect(self.save_user)
        btn_row.addWidget(save_btn)
        del_btn = QPushButton("🗑 حذف")
        del_btn.clicked.connect(self.delete_user)
        btn_row.addWidget(del_btn)
        root.addLayout(btn_row)

        self.load_list()

    def load_list(self):
        from models import User
        s = self.session_factory()
        try:
            rows = s.query(User).order_by(User.id).all()
            self.table.setRowCount(len(rows))
            for r, u in enumerate(rows):
                vals = [u.id, u.username, u.role, "بله" if u.active else "خیر"]
                for col, v in enumerate(vals):
                    self.table.setItem(r, col, QTableWidgetItem(str(v)))
        finally:
            s.close()

    def on_select(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        uid = int(self.table.item(rows[0].row(), 0).text())
        from models import User
        s = self.session_factory()
        try:
            u = s.get(User, uid)
            if not u:
                return
            self.current_id = uid
            self.username.setText(u.username)
            self.full_name.setText(u.full_name or "")
            self.password.setText("")
            self.role.setCurrentText(u.role or "Sales")
            self.active.setChecked(bool(u.active))
        finally:
            s.close()

    def clear_form(self):
        self.current_id = None
        self.table.clearSelection()
        self.username.setText("")
        self.full_name.setText("")
        self.password.setText("")
        self.role.setCurrentText("Sales")
        self.active.setChecked(True)

    def save_user(self):
        uname = self.username.text().strip()
        if not uname:
            warn(self, "خطا", "نام کاربری الزامی است.")
            return
        from models import User, hash_pw
        s = self.session_factory()
        try:
            if self.current_id:
                u = s.get(User, self.current_id)
            else:
                if s.query(User).filter_by(username=uname).first():
                    warn(self, "خطا", "این نام کاربری قبلاً استفاده شده است.")
                    return
                u = User(username=uname, password=hash_pw("123456"))
                s.add(u)
            u.username = uname
            u.full_name = self.full_name.text().strip()
            u.role = self.role.currentText()
            u.active = self.active.isChecked()
            if self.password.text().strip():
                u.password = hash_pw(self.password.text().strip())
            s.commit()
            self.current_id = u.id
        finally:
            s.close()
        self.load_list()
        info(self, "ذخیره شد", "کاربر ذخیره شد.")

    def delete_user(self):
        if not self.current_id:
            return
        if self.current_id == self.user.id:
            warn(self, "خطا", "نمی‌توانید کاربر جاری را حذف کنید.")
            return
        if not confirm(self, "حذف", "این کاربر حذف شود؟"):
            return
        from models import User
        s = self.session_factory()
        try:
            u = s.get(User, self.current_id)
            if u:
                s.delete(u)
                s.commit()
        finally:
            s.close()
        self.load_list()
        self.clear_form()
