from PySide6.QtWidgets import (QLineEdit, QTextEdit, QComboBox, QFormLayout, QLabel, QDoubleSpinBox,
                               QDateEdit, QWidget, QVBoxLayout, QPushButton, QMessageBox)
from PySide6.QtCore import QDate, Qt


def info(parent, title, text):
    QMessageBox.information(parent, title, text)


def warn(parent, title, text):
    QMessageBox.warning(parent, title, text)


def confirm(parent, title, text):
    return QMessageBox.question(parent, title, text) == QMessageBox.Yes


def build_form(parent_layout, fields):
    """fields: list of (key, label, kind). kind: 'text'|'area'|'num'|'date'|list(options).
    Returns dict key -> widget."""
    form = QFormLayout()
    widgets = {}
    for key, label, kind in fields:
        if kind == "area":
            w = QTextEdit()
            w.setFixedHeight(70)
        elif kind == "num":
            w = QDoubleSpinBox()
            w.setRange(-1e9, 1e9)
            w.setDecimals(2)
        elif kind == "date":
            w = QDateEdit()
            w.setCalendarPopup(True)
            w.setDate(QDate.currentDate())
        elif isinstance(kind, list):
            w = QComboBox()
            w.addItems(kind)
        else:
            w = QLineEdit()
        widgets[key] = w
        form.addRow(label + ":", w)
    parent_layout.addLayout(form)
    return widgets


def get_val(w):
    if isinstance(w, QTextEdit):
        return w.toPlainText().strip()
    if isinstance(w, QComboBox):
        return w.currentText()
    if isinstance(w, QDoubleSpinBox):
        return w.value()
    if isinstance(w, QDateEdit):
        return w.date().toString("yyyy-MM-dd")
    return w.text().strip()


def set_val(w, v):
    if v is None:
        v = ""
    if isinstance(w, QTextEdit):
        w.setPlainText(str(v))
    elif isinstance(w, QComboBox):
        i = w.findText(str(v))
        w.setCurrentIndex(i if i >= 0 else 0)
    elif isinstance(w, QDoubleSpinBox):
        try:
            w.setValue(float(v))
        except (TypeError, ValueError):
            w.setValue(0)
    elif isinstance(w, QDateEdit):
        d = QDate.fromString(str(v), "yyyy-MM-dd")
        w.setDate(d if d.isValid() else QDate.currentDate())
    else:
        w.setText(str(v))
