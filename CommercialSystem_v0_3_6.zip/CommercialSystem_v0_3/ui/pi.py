import datetime as dt
from ui.theme import style_table
from pathlib import Path

from PySide6.QtCore import QDate, Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTableWidget,
                               QTableWidgetItem, QComboBox, QLabel, QGridLayout, QTextEdit, QDateEdit,
                               QSplitter, QAbstractItemView, QHeaderView, QTabWidget, QDoubleSpinBox,
                               QFileDialog, QListWidget, QSpinBox)
from database import TEMPLATES_DIR, OUTPUT_DIR
from models import PI_STATUS
from ui.common import warn, confirm, info
import services.pdf as pdf_svc
import services.docx_template as tpl_svc

CURRENCIES = ["USD", "EUR", "AED", "CNY", "TRY", "AZN", "IRR"]
INCOTERMS = ["", "EXW", "FCA", "FAS", "FOB", "CFR", "CIF", "CPT", "CIP", "DAP", "DPU", "DDP"]
UNITS = ["MT", "KG", "Drum", "Bag", "Barrel", "Piece", "Liter", "Container"]


class PIPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.user = user
        self.current_id = None
        self.item_rows = []  # dicts: product_id, description, spec, qty, unit, unit_price

        root = QVBoxLayout(self)
        self.tabs = QTabWidget()
        root.addWidget(self.tabs)

        self.tabs.addTab(self.build_list_tab(), "📚 لیست PI")
        self.tabs.addTab(self.build_edit_tab(), "🧾 ایجاد / ویرایش")
        self.tabs.addTab(self.build_template_tab(), "📄 Templateهای Word")

        self.load_list()
        self.reload_company_combos()
        self.new_pi()

    # ============================================================= list tab
    def build_list_tab(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.pi_table = QTableWidget(0, 6)
        self.pi_table.setHorizontalHeaderLabels(["شناسه", "شماره PI", "تاریخ", "خریدار", "مبلغ", "وضعیت"])
        style_table(self.pi_table)
        self.pi_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.pi_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pi_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.pi_table.doubleClicked.connect(self.open_selected_pi)
        l.addWidget(self.pi_table)
        open_btn = QPushButton("✏️ باز کردن برای ویرایش")
        open_btn.clicked.connect(self.open_selected_pi)
        l.addWidget(open_btn)
        return w

    def load_list(self):
        from models import PI
        s = self.session_factory()
        try:
            rows = s.query(PI).order_by(PI.id.desc()).all()
            self.pi_table.setRowCount(len(rows))
            for r, p in enumerate(rows):
                vals = [p.id, p.pi_no, p.pi_date or "", p.buyer.company_name_fa if p.buyer else "",
                       f"{p.currency} {p.total:,.2f}" if p.total else "", p.status or ""]
                for col, v in enumerate(vals):
                    self.pi_table.setItem(r, col, QTableWidgetItem(str(v)))
        finally:
            s.close()

    def open_selected_pi(self):
        rows = self.pi_table.selectionModel().selectedRows()
        if not rows:
            return
        pid = int(self.pi_table.item(rows[0].row(), 0).text())
        self.load_pi(pid)
        self.tabs.setCurrentIndex(1)

    # ============================================================= edit tab
    def build_edit_tab(self):
        w = QWidget()
        root = QVBoxLayout(w)

        head = QHBoxLayout()
        new_btn = QPushButton("➕ PI جدید")
        new_btn.clicked.connect(self.new_pi)
        head.addWidget(new_btn)
        head.addStretch()
        root.addLayout(head)

        grid = QGridLayout()
        self.fields = {}
        grid.addWidget(QLabel("شماره PI:"), 0, 0)
        self.pi_no = QLineEdit(); grid.addWidget(self.pi_no, 0, 1)
        grid.addWidget(QLabel("تاریخ:"), 0, 2)
        self.pi_date = QDateEdit(); self.pi_date.setCalendarPopup(True); self.pi_date.setDate(QDate.currentDate())
        grid.addWidget(self.pi_date, 0, 3)
        grid.addWidget(QLabel("اعتبار (روز):"), 0, 4)
        self.validity = QSpinBox(); self.validity.setRange(1, 3650); self.validity.setValue(30)
        grid.addWidget(self.validity, 0, 5)

        grid.addWidget(QLabel("خریدار (Buyer):"), 1, 0)
        self.buyer_combo = QComboBox(); grid.addWidget(self.buyer_combo, 1, 1, 1, 2)
        grid.addWidget(QLabel("Consignee:"), 1, 3)
        self.consignee_combo = QComboBox(); grid.addWidget(self.consignee_combo, 1, 4, 1, 2)

        grid.addWidget(QLabel("ارز:"), 2, 0)
        self.currency = QComboBox(); self.currency.addItems(CURRENCIES); grid.addWidget(self.currency, 2, 1)
        grid.addWidget(QLabel("Incoterm:"), 2, 2)
        self.incoterm = QComboBox(); self.incoterm.addItems(INCOTERMS); grid.addWidget(self.incoterm, 2, 3)
        grid.addWidget(QLabel("وضعیت:"), 2, 4)
        self.status = QComboBox(); self.status.addItems(PI_STATUS); grid.addWidget(self.status, 2, 5)

        for i, (label, key) in enumerate([("شرایط پرداخت", "payment_terms"), ("تحویل", "delivery"),
                                          ("بسته‌بندی", "packing"), ("مبدأ", "origin"),
                                          ("بندر بارگیری", "loading_port"), ("بندر تخلیه", "discharge_port")]):
            grid.addWidget(QLabel(label + ":"), 3 + i // 3, (i % 3) * 2)
            e = QLineEdit()
            self.fields[key] = e
            grid.addWidget(e, 3 + i // 3, (i % 3) * 2 + 1)
        root.addLayout(grid)

        root.addWidget(QLabel("ملاحظات (Remark):"))
        self.remark = QTextEdit(); self.remark.setFixedHeight(45)
        root.addWidget(self.remark)

        root.addWidget(QLabel("<b>📦 کالاها</b>"))
        add_row = QHBoxLayout()
        self.product_pick = QComboBox()
        add_row.addWidget(self.product_pick, 3)
        self.qty_pick = QDoubleSpinBox(); self.qty_pick.setRange(0, 1e9); self.qty_pick.setValue(1)
        add_row.addWidget(self.qty_pick, 1)
        add_item_btn = QPushButton("➕ افزودن از دیتابیس محصولات")
        add_item_btn.clicked.connect(self.add_item_from_product)
        add_row.addWidget(add_item_btn)
        add_blank_btn = QPushButton("➕ ردیف خالی")
        add_blank_btn.clicked.connect(self.add_blank_item)
        add_row.addWidget(add_blank_btn)
        del_item_btn = QPushButton("🗑 حذف ردیف انتخابی")
        del_item_btn.clicked.connect(self.delete_item_row)
        add_row.addWidget(del_item_btn)
        root.addLayout(add_row)

        self.items_table = QTableWidget(0, 6)
        self.items_table.setHorizontalHeaderLabels(["شرح کالا", "مشخصات فنی", "مقدار", "واحد", "قیمت واحد", "مبلغ"])
        style_table(self.items_table)
        self.items_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.items_table.itemChanged.connect(self.recalc_totals)
        root.addWidget(self.items_table)

        self.total_label = QLabel("جمع کل: 0.00")
        self.total_label.setStyleSheet("font-weight:bold;font-size:14px;")
        root.addWidget(self.total_label)

        btn_row = QHBoxLayout()
        save_btn = QPushButton("💾 ذخیره PI")
        save_btn.clicked.connect(self.save_pi)
        btn_row.addWidget(save_btn)
        del_btn = QPushButton("🗑 حذف PI")
        del_btn.clicked.connect(self.delete_pi)
        btn_row.addWidget(del_btn)
        root.addLayout(btn_row)

        root.addWidget(QLabel("<b>🖨 صدور فایل</b>"))
        gen_row = QHBoxLayout()
        pdf_btn = QPushButton("📄 PDF (قالب داخلی)")
        pdf_btn.clicked.connect(self.generate_pdf)
        gen_row.addWidget(pdf_btn)
        self.tpl_combo = QComboBox()
        gen_row.addWidget(self.tpl_combo)
        docx_btn = QPushButton("📝 Word از Template")
        docx_btn.clicked.connect(self.generate_docx)
        gen_row.addWidget(docx_btn)
        tpdf_btn = QPushButton("📕 PDF از Template")
        tpdf_btn.clicked.connect(self.generate_template_pdf)
        gen_row.addWidget(tpdf_btn)
        root.addLayout(gen_row)
        self.output_label = QLabel("")
        self.output_label.setStyleSheet("color:green;")
        root.addWidget(self.output_label)

        return w

    def reload_company_combos(self):
        from models import Company
        s = self.session_factory()
        try:
            companies = s.query(Company).order_by(Company.company_name_fa).all()
            self._company_ids = [c.id for c in companies]
            labels = [f"{c.company_name_fa} ({c.country or '-'})" for c in companies]
            self.buyer_combo.clear(); self.buyer_combo.addItems(labels)
            self.consignee_combo.clear(); self.consignee_combo.addItems(["(مثل خریدار)"] + labels)
        finally:
            s.close()
        from models import Product
        s = self.session_factory()
        try:
            products = s.query(Product).order_by(Product.name_fa).all()
            self._product_ids = [p.id for p in products]
            self.product_pick.clear()
            self.product_pick.addItems([p.name_en or p.name_fa for p in products])
            self._products_cache = {p.id: p for p in products}
        finally:
            s.close()
        self.reload_templates()

    def reload_templates(self):
        self.tpl_combo.clear()
        files = sorted(TEMPLATES_DIR.glob("*.docx"))
        if not files:
            tpl_svc.make_sample_template(TEMPLATES_DIR / "sample_template.docx")
            files = sorted(TEMPLATES_DIR.glob("*.docx"))
        self.tpl_combo.addItems([f.name for f in files])

    # -------- items table helpers
    def add_item_from_product(self):
        idx = self.product_pick.currentIndex()
        if idx < 0 or not self._product_ids:
            return
        p = self._products_cache[self._product_ids[idx]]
        spec = "; ".join(f"{sp.parameter}: {sp.value}" for sp in p.specifications[:4])
        self._append_item_row(p.name_en or p.name_fa, spec, self.qty_pick.value(), p.unit or "MT", p.price or 0)

    def add_blank_item(self):
        self._append_item_row("", "", 0, "MT", 0)

    def _append_item_row(self, desc, spec, qty, unit, price):
        r = self.items_table.rowCount()
        self.items_table.blockSignals(True)
        self.items_table.insertRow(r)
        self.items_table.setItem(r, 0, QTableWidgetItem(desc))
        self.items_table.setItem(r, 1, QTableWidgetItem(spec))
        self.items_table.setItem(r, 2, QTableWidgetItem(f"{qty}"))
        unit_combo = QComboBox(); unit_combo.addItems(UNITS)
        if unit in UNITS:
            unit_combo.setCurrentText(unit)
        unit_combo.currentIndexChanged.connect(self.recalc_totals)
        self.items_table.setCellWidget(r, 3, unit_combo)
        self.items_table.setItem(r, 4, QTableWidgetItem(f"{price}"))
        amount_item = QTableWidgetItem("0.00")
        amount_item.setFlags(amount_item.flags() & ~Qt.ItemIsEditable)
        self.items_table.setItem(r, 5, amount_item)
        self.items_table.blockSignals(False)
        self.recalc_totals()

    def delete_item_row(self):
        rows = sorted({i.row() for i in self.items_table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.items_table.removeRow(r)
        self.recalc_totals()

    def recalc_totals(self, *_):
        total = 0.0
        self.items_table.blockSignals(True)
        for r in range(self.items_table.rowCount()):
            try:
                qty = float(self.items_table.item(r, 2).text() or 0)
                price = float(self.items_table.item(r, 4).text() or 0)
            except (ValueError, AttributeError):
                qty = price = 0
            amount = round(qty * price, 2)
            self.items_table.setItem(r, 5, QTableWidgetItem(f"{amount:,.2f}"))
            total += amount
        self.items_table.blockSignals(False)
        self.total_label.setText(f"جمع کل: {self.currency.currentText()} {total:,.2f}")
        self._total = total

    # -------- CRUD
    def new_pi(self):
        from models import PI
        self.current_id = None
        s = self.session_factory()
        try:
            n = s.query(PI).count() + 1
        finally:
            s.close()
        self.pi_no.setText(f"PI-{dt.date.today().year}-{n:04d}")
        self.pi_date.setDate(QDate.currentDate())
        self.validity.setValue(30)
        if self.buyer_combo.count():
            self.buyer_combo.setCurrentIndex(0)
        self.consignee_combo.setCurrentIndex(0)
        self.currency.setCurrentIndex(0)
        self.incoterm.setCurrentText("FOB")
        self.status.setCurrentText("Draft")
        for e in self.fields.values():
            e.setText("")
        self.remark.setPlainText("")
        self.items_table.setRowCount(0)
        self.recalc_totals()
        self.output_label.setText("")

    def load_pi(self, pid):
        from models import PI
        s = self.session_factory()
        try:
            p = s.get(PI, pid)
            if not p:
                return
            self.current_id = pid
            self.pi_no.setText(p.pi_no)
            d = QDate.fromString(p.pi_date or "", "yyyy-MM-dd")
            self.pi_date.setDate(d if d.isValid() else QDate.currentDate())
            self.validity.setValue(p.validity_days or 30)
            if p.buyer_id in self._company_ids:
                self.buyer_combo.setCurrentIndex(self._company_ids.index(p.buyer_id))
            self.consignee_combo.setCurrentIndex(
                self._company_ids.index(p.consignee_id) + 1 if p.consignee_id in self._company_ids else 0)
            self.currency.setCurrentText(p.currency or "USD")
            self.incoterm.setCurrentText(p.incoterm or "")
            self.status.setCurrentText(p.status or "Draft")
            for key, e in self.fields.items():
                e.setText(getattr(p, key) or "")
            self.remark.setPlainText(p.remark or "")
            self.items_table.setRowCount(0)
            for it in p.items:
                self._append_item_row(it.description or "", it.spec or "", it.qty or 0, it.unit or "MT",
                                      it.unit_price or 0)
        finally:
            s.close()
        self.output_label.setText("")

    def _gather_items(self):
        items = []
        for r in range(self.items_table.rowCount()):
            desc = self.items_table.item(r, 0).text().strip() if self.items_table.item(r, 0) else ""
            if not desc:
                continue
            spec = self.items_table.item(r, 1).text().strip() if self.items_table.item(r, 1) else ""
            try:
                qty = float(self.items_table.item(r, 2).text() or 0)
                price = float(self.items_table.item(r, 4).text() or 0)
            except ValueError:
                qty = price = 0
            unit_w = self.items_table.cellWidget(r, 3)
            unit = unit_w.currentText() if unit_w else "MT"
            items.append({"description": desc, "spec": spec, "qty": qty, "unit": unit,
                         "unit_price": price, "amount": round(qty * price, 2), "sort": r})
        return items

    def save_pi(self):
        no = self.pi_no.text().strip()
        if not no:
            warn(self, "خطا", "شماره PI الزامی است.")
            return
        if not self._company_ids:
            warn(self, "خطا", "ابتدا حداقل یک شرکت خریدار ثبت کنید.")
            return
        from models import PI, PIItem
        s = self.session_factory()
        try:
            existing = s.query(PI).filter(PI.pi_no == no).first()
            if existing and existing.id != self.current_id:
                warn(self, "خطا", "این شماره PI قبلاً استفاده شده است.")
                return
            if self.current_id:
                p = s.get(PI, self.current_id)
            else:
                p = PI(pi_no=no)
                s.add(p)
            p.pi_no = no
            p.pi_date = self.pi_date.date().toString("yyyy-MM-dd")
            p.validity_days = self.validity.value()
            p.buyer_id = self._company_ids[self.buyer_combo.currentIndex()]
            ci = self.consignee_combo.currentIndex()
            p.consignee_id = self._company_ids[ci - 1] if ci > 0 else None
            p.currency = self.currency.currentText()
            p.incoterm = self.incoterm.currentText()
            p.status = self.status.currentText()
            for key, e in self.fields.items():
                setattr(p, key, e.text().strip())
            p.remark = self.remark.toPlainText().strip()
            items = self._gather_items()
            p.total = sum(i["amount"] for i in items)
            s.flush()
            s.query(PIItem).filter_by(pi_id=p.id).delete()
            for i in items:
                s.add(PIItem(pi_id=p.id, **i))
            s.commit()
            self.current_id = p.id
        finally:
            s.close()
        self.load_list()
        info(self, "ذخیره شد", f"PI {no} ذخیره شد.")

    def delete_pi(self):
        if not self.current_id or not confirm(self, "حذف", "این PI حذف شود؟"):
            return
        from models import PI
        s = self.session_factory()
        try:
            p = s.get(PI, self.current_id)
            if p:
                s.delete(p)
                s.commit()
        finally:
            s.close()
        self.load_list()
        self.new_pi()

    # -------- document generation
    def generate_pdf(self):
        if not self.current_id:
            warn(self, "توجه", "ابتدا PI را ذخیره کنید.")
            return
        from models import PI, MyCompany
        s = self.session_factory()
        try:
            p, me = s.get(PI, self.current_id), s.get(MyCompany, 1)
            out = OUTPUT_DIR / f"{p.pi_no.replace('/', '-')}.pdf"
            pdf_svc.build_pi_pdf(p, me, out)
        finally:
            s.close()
        self.output_label.setText(f"ذخیره شد: {out}")
        info(self, "PDF صادر شد", str(out))

    def generate_docx(self):
        if not self.current_id:
            warn(self, "توجه", "ابتدا PI را ذخیره کنید.")
            return
        tpl = self.tpl_combo.currentText()
        if not tpl:
            warn(self, "خطا", "Templateای انتخاب نشده.")
            return
        from models import PI, MyCompany
        s = self.session_factory()
        try:
            p, me = s.get(PI, self.current_id), s.get(MyCompany, 1)
            ctx = tpl_svc.pi_context(p, me)
            out = OUTPUT_DIR / f"{p.pi_no.replace('/', '-')}.docx"
            tpl_svc.fill_docx_template(TEMPLATES_DIR / tpl, ctx, out)
        finally:
            s.close()
        self.output_label.setText(f"ذخیره شد: {out}")
        info(self, "Word صادر شد", str(out))

    def generate_template_pdf(self):
        if not self.current_id:
            warn(self, "توجه", "ابتدا PI را ذخیره کنید.")
            return
        tpl = self.tpl_combo.currentText()
        if not tpl:
            return
        from models import PI, MyCompany
        s = self.session_factory()
        try:
            p, me = s.get(PI, self.current_id), s.get(MyCompany, 1)
            ctx = tpl_svc.pi_context(p, me)
            out = OUTPUT_DIR / f"{p.pi_no.replace('/', '-')}.docx"
            tpl_svc.fill_docx_template(TEMPLATES_DIR / tpl, ctx, out)
        finally:
            s.close()
        pdf = tpl_svc.docx_to_pdf(out)
        if pdf:
            self.output_label.setText(f"ذخیره شد: {pdf}")
            info(self, "PDF صادر شد", str(pdf))
        else:
            self.output_label.setText(f"LibreOffice نصب نیست؛ Word ذخیره شد: {out}")
            warn(self, "توجه", "برای تبدیل به PDF باید LibreOffice نصب باشد. فایل Word صادر شد.")

    # ============================================================= templates tab
    def build_template_tab(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(QLabel(
            "فرم خام PI خود را (Word) با Placeholderهای زیر آماده و آپلود کنید؛ برنامه اطلاعات دیتابیس را\n"
            "در همان فرم قرار می‌دهد. ردیف جدولی که شامل {{item_...}} باشد برای هر کالا تکرار می‌شود."))
        ph = QTextEdit()
        ph.setReadOnly(True)
        ph.setPlainText("  ".join("{{%s}}" % p for p in tpl_svc.PLACEHOLDERS) + "\n\nجدول کالاها:\n" +
                        "  ".join("{{%s}}" % p for p in tpl_svc.ITEM_PLACEHOLDERS))
        ph.setFixedHeight(140)
        l.addWidget(ph)

        row = QHBoxLayout()
        up_btn = QPushButton("📤 آپلود Template (.docx)")
        up_btn.clicked.connect(self.upload_template)
        row.addWidget(up_btn)
        dl_btn = QPushButton("⬇️ دانلود Template نمونه")
        dl_btn.clicked.connect(self.download_sample)
        row.addWidget(dl_btn)
        l.addLayout(row)

        self.tpl_list = QListWidget()
        l.addWidget(self.tpl_list)
        del_btn = QPushButton("🗑 حذف Template انتخابی")
        del_btn.clicked.connect(self.delete_template)
        l.addWidget(del_btn)
        self.refresh_template_list()
        return w

    def refresh_template_list(self):
        self.tpl_list.clear()
        for f in sorted(TEMPLATES_DIR.glob("*.docx")):
            self.tpl_list.addItem(f.name)

    def upload_template(self):
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب Template", "", "Word (*.docx)")
        if not path:
            return
        import shutil
        shutil.copy2(path, TEMPLATES_DIR / Path(path).name)
        self.refresh_template_list()
        self.reload_templates()
        info(self, "ذخیره شد", "Template ذخیره شد.")

    def download_sample(self):
        out, _ = QFileDialog.getSaveFileName(self, "ذخیره Template نمونه", "sample_template.docx",
                                             "Word (*.docx)")
        if not out:
            return
        sample = TEMPLATES_DIR / "sample_template.docx"
        if not sample.exists():
            tpl_svc.make_sample_template(sample)
        import shutil
        shutil.copy2(sample, out)
        info(self, "ذخیره شد", out)

    def delete_template(self):
        item = self.tpl_list.currentItem()
        if not item or item.text() == "sample_template.docx":
            return
        (TEMPLATES_DIR / item.text()).unlink(missing_ok=True)
        self.refresh_template_list()
        self.reload_templates()
