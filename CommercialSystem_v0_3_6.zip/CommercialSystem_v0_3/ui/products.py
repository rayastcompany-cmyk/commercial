import shutil
from ui.theme import style_table
import uuid
from pathlib import Path

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTableWidget,
                               QTableWidgetItem, QComboBox, QTextEdit, QLabel, QGridLayout, QSplitter,
                               QListWidget, QListWidgetItem, QFileDialog, QAbstractItemView, QHeaderView,
                               QTabWidget)
from database import IMAGES_DIR
from models import IMAGE_KINDS
from ui.common import warn, confirm
from ui.import_products_excel import ProductExcelImportDialog

FIELDS = [("نام محصول (فارسی) *", "name_fa"), ("نام انگلیسی", "name_en"), ("کد محصول", "product_code"),
          ("HS Code", "hs_code"), ("دسته‌بندی", "category"), ("زیردسته", "subcategory"),
          ("مبدأ (Origin)", "origin"), ("بسته‌بندی", "packaging"), ("حداقل سفارش (MOQ)", "moq"),
          ("واحد", "unit"), ("قیمت", "price"), ("ارز", "currency"), ("Incoterm", "incoterm"),
          ("بندر بارگیری", "loading_port"), ("مقصد", "destination")]

PRESETS = {
    "Bitumen": [("Penetration at 25°C (0.1 mm)", "", "ASTM D5"), ("Softening Point (°C)", "", "ASTM D36"),
                ("Ductility at 25°C (cm)", "", "ASTM D113"), ("Flash Point (°C)", "", "ASTM D92"),
                ("Solubility in TCE (%)", "", "ASTM D2042"), ("Specific Gravity", "", "ASTM D70")],
    "LPG": [("Propane (%)", "", ""), ("i-Butane (%)", "", ""), ("n-Butane (%)", "", ""), ("C5+ (%)", "", ""),
            ("Sulfur (ppm)", "", ""), ("Density (kg/m3)", "", ""), ("Vapor Pressure (kPa)", "", "")],
    "Base Oil": [("Viscosity at 40°C (cSt)", "", "ASTM D445"), ("Viscosity at 100°C (cSt)", "", "ASTM D445"),
                 ("Viscosity Index", "", "ASTM D2270"), ("Flash Point (°C)", "", "ASTM D92"),
                 ("Pour Point (°C)", "", "ASTM D97"), ("Color", "", "ASTM D1500")],
    "Paraffin Wax": [("Melting Point (°C)", "", "ASTM D87"), ("Oil Content (%)", "", "ASTM D721"),
                     ("Color (Saybolt)", "", "ASTM D156"), ("Flash Point (°C)", "", "ASTM D92")],
    "HDPE Film Grade": [("Melt flow rate (g/10 min)", "0.04", "ISO 1133"), ("Density (kg/m3)", "952", "ISO 1183"),
                        ("Tensile Strength at yield (MPa)", "27", "ISO 527-1,-2"),
                        ("Elongation at break (%)", ">500", "ISO 527-1,-2"),
                        ("Melting temperature (°C)", "131", "ISO 11357")],
}


class ProductsPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.user = user
        self.current_id = None
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("جست‌وجوی محصول...")
        self.search.textChanged.connect(self.load_list)
        top.addWidget(self.search)
        new_btn = QPushButton("➕ محصول جدید")
        new_btn.clicked.connect(self.new_product)
        top.addWidget(new_btn)
        imp_btn = QPushButton("📥 ورود از Excel")
        imp_btn.clicked.connect(self.import_excel)
        top.addWidget(imp_btn)
        root.addLayout(top)

        split = QSplitter()
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["شناسه", "نام محصول", "دسته‌بندی", "مبدأ", "قیمت"])
        style_table(self.table)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.on_select)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        split.addWidget(self.table)

        detail = QWidget()
        dl = QVBoxLayout(detail)
        self.tabs = QTabWidget()
        dl.addWidget(self.tabs)

        info_tab = QWidget()
        il = QVBoxLayout(info_tab)
        grid = QGridLayout()
        self.fields = {}
        for i, (label, key) in enumerate(FIELDS):
            grid.addWidget(QLabel(label + ":"), i // 2, (i % 2) * 2)
            e = QLineEdit()
            self.fields[key] = e
            grid.addWidget(e, i // 2, (i % 2) * 2 + 1)
        il.addLayout(grid)
        il.addWidget(QLabel("توضیحات:"))
        self.description = QTextEdit(); self.description.setFixedHeight(60)
        il.addWidget(self.description)
        btn_row = QHBoxLayout()
        save_btn = QPushButton("💾 ذخیره محصول")
        save_btn.clicked.connect(self.save_product)
        btn_row.addWidget(save_btn)
        del_btn = QPushButton("🗑 حذف محصول")
        del_btn.clicked.connect(self.delete_product)
        btn_row.addWidget(del_btn)
        il.addLayout(btn_row)
        il.addStretch()
        self.tabs.addTab(info_tab, "اطلاعات")

        spec_tab = QWidget()
        sl = QVBoxLayout(spec_tab)
        srow = QHBoxLayout()
        srow.addWidget(QLabel("بارگذاری الگوی آماده:"))
        self.preset = QComboBox()
        self.preset.addItems(["—"] + list(PRESETS))
        srow.addWidget(self.preset)
        apply_btn = QPushButton("اعمال")
        apply_btn.clicked.connect(self.apply_preset)
        srow.addWidget(apply_btn)
        add_row_btn = QPushButton("➕ ردیف جدید")
        add_row_btn.clicked.connect(lambda: self.spec_table.setRowCount(self.spec_table.rowCount() + 1))
        srow.addWidget(add_row_btn)
        del_row_btn = QPushButton("🗑 حذف ردیف انتخابی")
        del_row_btn.clicked.connect(self.delete_spec_row)
        srow.addWidget(del_row_btn)
        sl.addLayout(srow)
        self.spec_table = QTableWidget(0, 3)
        self.spec_table.setHorizontalHeaderLabels(["پارامتر (Property)", "مقدار (Value)", "روش تست (Method)"])
        style_table(self.spec_table)
        self.spec_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        sl.addWidget(self.spec_table)
        spec_save = QPushButton("💾 ذخیره Specification")
        spec_save.clicked.connect(self.save_specs)
        sl.addWidget(spec_save)
        self.tabs.addTab(spec_tab, "🧪 Specification")

        img_tab = QWidget()
        gl = QVBoxLayout(img_tab)
        irow = QHBoxLayout()
        self.img_kind = QComboBox()
        self.img_kind.addItems(IMAGE_KINDS)
        irow.addWidget(QLabel("نوع عکس:"))
        irow.addWidget(self.img_kind)
        up_btn = QPushButton("📤 آپلود عکس (چندتایی)")
        up_btn.clicked.connect(self.upload_images)
        irow.addWidget(up_btn)
        del_img_btn = QPushButton("🗑 حذف عکس انتخابی")
        del_img_btn.clicked.connect(self.delete_image)
        irow.addWidget(del_img_btn)
        gl.addLayout(irow)
        self.img_list = QListWidget()
        self.img_list.setViewMode(QListWidget.IconMode)
        self.img_list.setIconSize(QSize(140, 140))
        self.img_list.setResizeMode(QListWidget.Adjust)
        self.img_list.setSpacing(10)
        gl.addWidget(self.img_list)
        self.tabs.addTab(img_tab, "🖼 تصاویر")

        split.addWidget(detail)
        self.table.setMinimumWidth(380)
        split.setStretchFactor(0, 4)
        split.setStretchFactor(1, 6)
        root.addWidget(split)

        self.load_list()
        self.clear_form()

    # ---------------------------------------------------------------- list
    def load_list(self):
        from models import Product
        s = self.session_factory()
        try:
            q = self.search.text().strip()
            query = s.query(Product)
            if q:
                query = query.filter(Product.name_fa.contains(q) | Product.name_en.contains(q))
            rows = query.order_by(Product.id.desc()).all()
            self.table.setRowCount(len(rows))
            for r, p in enumerate(rows):
                vals = [p.id, p.name_fa, p.category or "", p.origin or "",
                       f"{p.price:,.2f}" if p.price else ""]
                for col, v in enumerate(vals):
                    self.table.setItem(r, col, QTableWidgetItem(str(v)))
        finally:
            s.close()

    def on_select(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        self.load_product(int(self.table.item(rows[0].row(), 0).text()))

    # ---------------------------------------------------------------- form
    def clear_form(self):
        self.current_id = None
        for e in self.fields.values():
            e.setText("")
        self.description.setPlainText("")
        self.spec_table.setRowCount(0)
        self.img_list.clear()

    def new_product(self):
        self.table.clearSelection()
        self.clear_form()
        self.tabs.setCurrentIndex(0)

    def load_product(self, pid):
        from models import Product
        s = self.session_factory()
        try:
            p = s.get(Product, pid)
            if not p:
                return
            self.current_id = pid
            for key, e in self.fields.items():
                v = getattr(p, key)
                e.setText("" if v is None else str(v))
            self.description.setPlainText(p.description or "")
            self.spec_table.setRowCount(len(p.specifications))
            for r, sp in enumerate(p.specifications):
                for c, v in enumerate([sp.parameter, sp.value, sp.method]):
                    self.spec_table.setItem(r, c, QTableWidgetItem(v or ""))
            self.img_list.clear()
            for im in p.images:
                self.add_image_item(im.id, im.path, im.kind)
        finally:
            s.close()

    def save_product(self):
        from models import Product
        name = self.fields["name_fa"].text().strip()
        if not name:
            warn(self, "خطا", "نام محصول الزامی است.")
            return
        s = self.session_factory()
        try:
            if self.current_id:
                p = s.get(Product, self.current_id)
            else:
                p = Product(name_fa=name)
                s.add(p)
            for key, e in self.fields.items():
                val = e.text().strip()
                if key in ("price", "available_qty"):
                    try:
                        val = float(val) if val else None
                    except ValueError:
                        val = None
                setattr(p, key, val)
            p.description = self.description.toPlainText().strip()
            s.commit()
            self.current_id = p.id
        finally:
            s.close()
        self.load_list()
        self.load_product(self.current_id)

    def delete_product(self):
        if not self.current_id or not confirm(self, "حذف", "محصول و مشخصات/تصاویر آن حذف شود؟"):
            return
        from models import Product
        s = self.session_factory()
        try:
            p = s.get(Product, self.current_id)
            if p:
                s.delete(p)
                s.commit()
        finally:
            s.close()
        self.load_list()
        self.new_product()

    # ---------------------------------------------------------------- specs
    def apply_preset(self):
        key = self.preset.currentText()
        if key not in PRESETS:
            return
        rows = PRESETS[key]
        self.spec_table.setRowCount(len(rows))
        for r, (param, val, method) in enumerate(rows):
            for c, v in enumerate([param, val, method]):
                self.spec_table.setItem(r, c, QTableWidgetItem(v))

    def delete_spec_row(self):
        rows = sorted({i.row() for i in self.spec_table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.spec_table.removeRow(r)

    def save_specs(self):
        if not self.current_id:
            warn(self, "توجه", "ابتدا محصول را ذخیره کنید.")
            return
        from models import ProductSpecification
        s = self.session_factory()
        try:
            s.query(ProductSpecification).filter_by(product_id=self.current_id).delete()
            for r in range(self.spec_table.rowCount()):
                param = self.spec_table.item(r, 0)
                param = param.text().strip() if param else ""
                if not param:
                    continue
                val = self.spec_table.item(r, 1)
                method = self.spec_table.item(r, 2)
                s.add(ProductSpecification(product_id=self.current_id, parameter=param,
                                           value=val.text().strip() if val else "",
                                           method=method.text().strip() if method else "", sort=r))
            s.commit()
        finally:
            s.close()
        warn(self, "ذخیره شد", "Specification ذخیره شد.")

    # ---------------------------------------------------------------- images
    def add_image_item(self, img_id, rel_path, kind):
        p = IMAGES_DIR / Path(rel_path).name
        item = QListWidgetItem(kind or "")
        if p.exists():
            item.setIcon(QIcon(QPixmap(str(p)).scaled(140, 140, Qt.KeepAspectRatio, Qt.SmoothTransformation)))
        item.setData(Qt.UserRole, img_id)
        self.img_list.addItem(item)

    def upload_images(self):
        if not self.current_id:
            warn(self, "توجه", "ابتدا محصول را ذخیره کنید.")
            return
        paths, _ = QFileDialog.getOpenFileNames(self, "انتخاب عکس", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if not paths:
            return
        from models import ProductImage
        s = self.session_factory()
        try:
            for src in paths:
                ext = Path(src).suffix.lower() or ".png"
                name = f"{uuid.uuid4().hex}{ext}"
                shutil.copy2(src, IMAGES_DIR / name)
                s.add(ProductImage(product_id=self.current_id, path=f"images/{name}",
                                   kind=self.img_kind.currentText()))
            s.commit()
        finally:
            s.close()
        self.load_product(self.current_id)

    def import_excel(self):
        dlg = ProductExcelImportDialog(self.session_factory, self)
        dlg.exec()
        self.load_list()

    def delete_image(self):
        item = self.img_list.currentItem()
        if not item:
            return
        img_id = item.data(Qt.UserRole)
        from models import ProductImage
        s = self.session_factory()
        try:
            im = s.get(ProductImage, img_id)
            if im:
                s.delete(im)
                s.commit()
        finally:
            s.close()
        self.load_product(self.current_id)
