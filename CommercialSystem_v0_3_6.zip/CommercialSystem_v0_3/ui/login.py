from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QFormLayout, QLineEdit, QPushButton, QMessageBox, QLabel,
                               QVBoxLayout, QFrame)
from ui.theme import NAVY, GOLD, MUTED


class LoginDialog(QDialog):
    def __init__(self, session_factory):
        super().__init__()
        self.session_factory = session_factory
        self.setWindowTitle("ورود به سیستم بازرگانی")
        self.setFixedSize(400, 430)
        self.setStyleSheet(f"QDialog {{ background: {NAVY}; }}")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        badge = QLabel("🏢")
        badge.setAlignment(Qt.AlignCenter)
        badge.setStyleSheet("font-size:46px;padding-top:36px;")
        outer.addWidget(badge)

        title = QLabel("سیستم مدیریت بازرگانی")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:19px;font-weight:800;color:white;padding-bottom:2px;")
        outer.addWidget(title)

        sub = QLabel("مدیریت شرکت‌ها، محصولات، PI و کاتالوگ")
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet(f"color:{GOLD};font-size:12px;padding-bottom:18px;")
        outer.addWidget(sub)

        card = QFrame()
        card.setStyleSheet("QFrame{background:white;border-top-left-radius:18px;"
                           "border-top-right-radius:18px;}")
        cl = QVBoxLayout(card)
        cl.setContentsMargins(30, 30, 30, 30)
        cl.setSpacing(10)

        form = QFormLayout()
        form.setSpacing(10)
        self.username = QLineEdit()
        self.username.setPlaceholderText("نام کاربری")
        self.password = QLineEdit()
        self.password.setPlaceholderText("رمز عبور")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.returnPressed.connect(self.check_login)
        for w in (self.username, self.password):
            w.setStyleSheet("padding:10px;border-radius:8px;border:1px solid #DDE3ED;")
        form.addRow(self.username)
        form.addRow(self.password)
        cl.addLayout(form)

        btn = QPushButton("ورود به سیستم")
        btn.setStyleSheet(f"background:{NAVY};color:white;padding:11px;border-radius:8px;"
                          "font-weight:700;font-size:14px;")
        btn.clicked.connect(self.check_login)
        cl.addWidget(btn)

        hint = QLabel("پیش‌فرض: admin / admin")
        hint.setAlignment(Qt.AlignCenter)
        hint.setStyleSheet(f"color:{MUTED};font-size:11px;padding-top:6px;")
        cl.addWidget(hint)
        cl.addStretch()

        outer.addWidget(card, 1)
        self.accepted_user = None

    def check_login(self):
        from models import User, hash_pw
        session = self.session_factory()
        try:
            user = session.query(User).filter_by(
                username=self.username.text().strip(),
                password=hash_pw(self.password.text()),
                active=True,
            ).first()
            if user:
                self.accepted_user = user
                session.expunge(user)
                self.accept()
            else:
                QMessageBox.warning(self, "خطا", "نام کاربری، رمز عبور نادرست یا کاربر غیرفعال است.")
        finally:
            session.close()
