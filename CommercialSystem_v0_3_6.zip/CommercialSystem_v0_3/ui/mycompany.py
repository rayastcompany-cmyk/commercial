import shutil
import uuid
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QTextEdit,
                               QLabel, QGridLayout, QFileDialog, QScrollArea)
from database import IMAGES_DIR
from ui.common import info

FIELDS = [("Company Name (EN)", "name"), ("نام فارسی", "name_fa"), ("Tagline (روی جلد کاتالوگ)", "tagline"),
          ("Website", "website"), ("Email", "email"), ("Telephone", "phone"), ("WhatsApp", "whatsapp"),
          ("LinkedIn", "linkedin")]
BANK_FIELDS = [("Bank Name", "bank_name"), ("Beneficiary", "beneficiary"), ("Account No", "account_no"),
              ("IBAN", "iban"), ("SWIFT", "swift")]


class MyCompanyPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        self.logo_path = None
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        inner = QWidget()
        root = QVBoxLayout(inner)
        root.addWidget(QLabel("<b>🏢 اطلاعات شرکت من (در PI و کاتالوگ استفاده می‌شود)</b>"))

        grid = QGridLayout()
        self.fields = {}
        for i, (label, key) in enumerate(FIELDS):
            grid.addWidget(QLabel(label + ":"), i // 2, (i % 2) * 2)
            e = QLineEdit()
            self.fields[key] = e
            grid.addWidget(e, i // 2, (i % 2) * 2 + 1)
        root.addLayout(grid)

        root.addWidget(QLabel("Address:"))
        self.address = QTextEdit(); self.address.setFixedHeight(50)
        root.addWidget(self.address)
        root.addWidget(QLabel("About Us:"))
        self.about = QTextEdit(); self.about.setFixedHeight(60)
        root.addWidget(self.about)
        root.addWidget(QLabel("Markets:"))
        self.markets = QTextEdit(); self.markets.setFixedHeight(50)
        root.addWidget(self.markets)

        logo_row = QHBoxLayout()
        self.logo_preview = QLabel("بدون لوگو")
        self.logo_preview.setFixedSize(120, 80)
        self.logo_preview.setStyleSheet("border:1px solid #ccc;")
        logo_row.addWidget(self.logo_preview)
        logo_btn = QPushButton("📤 انتخاب لوگو")
        logo_btn.clicked.connect(self.pick_logo)
        logo_row.addWidget(logo_btn)
        logo_row.addStretch()
        root.addLayout(logo_row)

        root.addWidget(QLabel("<b>🏦 اطلاعات بانکی</b>"))
        bgrid = QGridLayout()
        for i, (label, key) in enumerate(BANK_FIELDS):
            bgrid.addWidget(QLabel(label + ":"), i // 2, (i % 2) * 2)
            e = QLineEdit()
            self.fields[key] = e
            bgrid.addWidget(e, i // 2, (i % 2) * 2 + 1)
        root.addLayout(bgrid)
        root.addWidget(QLabel("Bank Address:"))
        self.bank_address = QTextEdit(); self.bank_address.setFixedHeight(40)
        root.addWidget(self.bank_address)

        save_btn = QPushButton("💾 ذخیره")
        save_btn.clicked.connect(self.save)
        root.addWidget(save_btn)
        root.addStretch()
        scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.addWidget(scroll)
        self.load()

    def load(self):
        from models import MyCompany
        s = self.session_factory()
        try:
            m = s.get(MyCompany, 1)
            if not m:
                return
            for key, e in self.fields.items():
                e.setText(getattr(m, key) or "")
            self.address.setPlainText(m.address or "")
            self.about.setPlainText(m.about or "")
            self.markets.setPlainText(m.markets or "")
            self.bank_address.setPlainText(m.bank_address or "")
            self.logo_path = m.logo
            if m.logo:
                p = IMAGES_DIR / Path(m.logo).name
                if p.exists():
                    self.logo_preview.setPixmap(QPixmap(str(p)).scaled(120, 80, Qt.KeepAspectRatio,
                                                                       Qt.SmoothTransformation))
        finally:
            s.close()

    def pick_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب لوگو", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if not path:
            return
        ext = Path(path).suffix.lower() or ".png"
        name = f"{uuid.uuid4().hex}{ext}"
        shutil.copy2(path, IMAGES_DIR / name)
        self.logo_path = f"images/{name}"
        self.logo_preview.setPixmap(QPixmap(str(IMAGES_DIR / name)).scaled(120, 80, Qt.KeepAspectRatio,
                                                                            Qt.SmoothTransformation))

    def save(self):
        from models import MyCompany
        s = self.session_factory()
        try:
            m = s.get(MyCompany, 1) or MyCompany(id=1)
            for key, e in self.fields.items():
                setattr(m, key, e.text().strip())
            m.address = self.address.toPlainText().strip()
            m.about = self.about.toPlainText().strip()
            m.markets = self.markets.toPlainText().strip()
            m.bank_address = self.bank_address.toPlainText().strip()
            if self.logo_path:
                m.logo = self.logo_path
            s.merge(m)
            s.commit()
        finally:
            s.close()
        info(self, "ذخیره شد", "اطلاعات شرکت ذخیره شد.")
