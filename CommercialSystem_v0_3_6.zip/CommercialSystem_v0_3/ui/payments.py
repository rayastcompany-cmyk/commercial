import datetime as dt
from ui.theme import style_table

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel, QPushButton,
                               QTableWidget, QTableWidgetItem, QDoubleSpinBox, QLineEdit, QDateEdit,
                               QAbstractItemView, QHeaderView)
from ui.common import warn, confirm

CURRENCIES = ["USD", "EUR", "AED", "CNY", "TRY", "AZN", "IRR"]


class PaymentsPage(QWidget):
    def __init__(self, session_factory, user):
        super().__init__()
        self.session_factory = session_factory
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        top.addWidget(QLabel("PI:"))
        self.pi_combo = QComboBox()
        self.pi_combo.currentIndexChanged.connect(self.load_payments)
        top.addWidget(self.pi_combo, 3)
        root.addLayout(top)

        stats = QHBoxLayout()
        self.total_label = QLabel("مبلغ PI: -")
        self.paid_label = QLabel("پرداخت‌شده: -")
        self.remain_label = QLabel("مانده: -")
        for lb in (self.total_label, self.paid_label, self.remain_label):
            lb.setStyleSheet("font-weight:bold;padding:6px;border:1px solid #ddd;border-radius:4px;")
            stats.addWidget(lb)
        root.addLayout(stats)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["شناسه", "تاریخ", "مبلغ", "ارز", "روش", "مرجع"])
        style_table(self.table)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        root.addWidget(self.table)

        add_row = QHBoxLayout()
        self.amount = QDoubleSpinBox(); self.amount.setRange(0, 1e9); self.amount.setDecimals(2)
        add_row.addWidget(QLabel("مبلغ:")); add_row.addWidget(self.amount)
        self.currency = QComboBox(); self.currency.addItems(CURRENCIES)
        add_row.addWidget(QLabel("ارز:")); add_row.addWidget(self.currency)
        self.method = QLineEdit(); self.method.setPlaceholderText("TT / LC / Cash ...")
        add_row.addWidget(QLabel("روش:")); add_row.addWidget(self.method)
        self.reference = QLineEdit()
        add_row.addWidget(QLabel("مرجع:")); add_row.addWidget(self.reference)
        self.pay_date = QDateEdit(); self.pay_date.setCalendarPopup(True); self.pay_date.setDate(QDate.currentDate())
        add_row.addWidget(QLabel("تاریخ:")); add_row.addWidget(self.pay_date)
        root.addLayout(add_row)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("➕ ثبت پرداخت")
        add_btn.clicked.connect(self.add_payment)
        btn_row.addWidget(add_btn)
        del_btn = QPushButton("🗑 حذف پرداخت انتخابی")
        del_btn.clicked.connect(self.delete_payment)
        btn_row.addWidget(del_btn)
        root.addLayout(btn_row)

        self.reload_pis()

    def reload_pis(self):
        from models import PI
        s = self.session_factory()
        try:
            rows = s.query(PI).order_by(PI.id.desc()).all()
            self._pi_ids = [p.id for p in rows]
            self.pi_combo.clear()
            self.pi_combo.addItems([f"{p.pi_no} - {p.buyer.company_name_fa if p.buyer else ''}" for p in rows])
        finally:
            s.close()
        self.load_payments()

    def current_pi_id(self):
        idx = self.pi_combo.currentIndex()
        return self._pi_ids[idx] if 0 <= idx < len(getattr(self, "_pi_ids", [])) else None

    def load_payments(self):
        pid = self.current_pi_id()
        self.table.setRowCount(0)
        if not pid:
            self.total_label.setText("مبلغ PI: -")
            self.paid_label.setText("پرداخت‌شده: -")
            self.remain_label.setText("مانده: -")
            return
        from models import PI
        s = self.session_factory()
        try:
            p = s.get(PI, pid)
            paid = sum(pay.amount or 0 for pay in p.payments)
            self.total_label.setText(f"مبلغ PI: {p.currency} {p.total or 0:,.2f}")
            self.paid_label.setText(f"پرداخت‌شده: {paid:,.2f}")
            self.remain_label.setText(f"مانده: {(p.total or 0) - paid:,.2f}")
            self.currency.setCurrentText(p.currency or "USD")
            self.table.setRowCount(len(p.payments))
            for r, pay in enumerate(p.payments):
                vals = [pay.id, pay.pay_date or "", f"{pay.amount:,.2f}", pay.currency or "",
                       pay.method or "", pay.reference or ""]
                for col, v in enumerate(vals):
                    self.table.setItem(r, col, QTableWidgetItem(str(v)))
        finally:
            s.close()

    def add_payment(self):
        pid = self.current_pi_id()
        if not pid:
            warn(self, "توجه", "ابتدا یک PI ثبت کنید.")
            return
        from models import Payment
        s = self.session_factory()
        try:
            s.add(Payment(pi_id=pid, pay_date=self.pay_date.date().toString("yyyy-MM-dd"),
                         amount=self.amount.value(), currency=self.currency.currentText(),
                         method=self.method.text().strip(), reference=self.reference.text().strip()))
            s.commit()
        finally:
            s.close()
        self.amount.setValue(0)
        self.method.setText("")
        self.reference.setText("")
        self.load_payments()

    def delete_payment(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows or not confirm(self, "حذف", "این پرداخت حذف شود؟"):
            return
        pay_id = int(self.table.item(rows[0].row(), 0).text())
        from models import Payment
        s = self.session_factory()
        try:
            pay = s.get(Payment, pay_id)
            if pay:
                s.delete(pay)
                s.commit()
        finally:
            s.close()
        self.load_payments()
