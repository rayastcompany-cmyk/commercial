"""Central visual theme for the app (navy / gold, matching the PI & catalog PDFs)."""

NAVY = "#0B2545"
NAVY_LIGHT = "#13315C"
NAVY_LIGHTER = "#1B4079"
GOLD = "#C9A227"
GOLD_LIGHT = "#E4C55E"
BG = "#F4F6FA"
CARD_BG = "#FFFFFF"
BORDER = "#DDE3ED"
TEXT = "#1F2937"
MUTED = "#6B7280"
DANGER = "#DC2626"
SUCCESS = "#16A34A"

FONT_FAMILY = "Vazirmatn, Tahoma, 'Segoe UI', Arial"

QSS = f"""
* {{
    font-family: {FONT_FAMILY};
    outline: none;
}}
QMainWindow, QWidget {{
    background: {BG};
    color: {TEXT};
    font-size: 13px;
}}
QScrollArea, QScrollArea > QWidget > QWidget {{
    background: transparent;
    border: none;
}}

/* ---- generic buttons ---- */
QPushButton {{
    background: {CARD_BG};
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 600;
}}
QPushButton:hover {{
    background: #EEF2F8;
    border-color: {NAVY_LIGHTER};
}}
QPushButton:pressed {{
    background: #E3E9F3;
}}
QPushButton:disabled {{
    color: #B0B7C3;
    background: #F1F3F7;
}}

/* ---- primary / save buttons (heuristic: text starts with these emoji) ---- */
QPushButton[cssClass="primary"] {{
    background: {NAVY};
    color: white;
    border: 1px solid {NAVY};
}}
QPushButton[cssClass="primary"]:hover {{
    background: {NAVY_LIGHTER};
}}
QPushButton[cssClass="danger"] {{
    color: {DANGER};
    border-color: #F3C6C6;
}}
QPushButton[cssClass="danger"]:hover {{
    background: #FDECEC;
}}

/* ---- inputs ---- */
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QDateEdit, QDoubleSpinBox, QSpinBox {{
    background: {CARD_BG};
    border: 1px solid {BORDER};
    border-radius: 6px;
    padding: 6px 8px;
    selection-background-color: {GOLD_LIGHT};
}}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus, QDateEdit:focus,
QDoubleSpinBox:focus, QSpinBox:focus {{
    border: 1.5px solid {NAVY_LIGHTER};
}}
QComboBox::drop-down {{
    border: none;
    width: 22px;
}}
QComboBox QAbstractItemView {{
    background: {CARD_BG};
    border: 1px solid {BORDER};
    selection-background-color: {NAVY_LIGHTER};
    selection-color: white;
    outline: none;
}}

/* ---- labels ---- */
QLabel {{
    color: {TEXT};
    background: transparent;
}}
QLabel[cssClass="h1"] {{
    font-size: 20px;
    font-weight: 700;
    color: {NAVY};
}}
QLabel[cssClass="h2"] {{
    font-size: 15px;
    font-weight: 700;
    color: {NAVY};
}}
QLabel[cssClass="muted"] {{
    color: {MUTED};
}}

/* ---- tables ---- */
QTableWidget {{
    background: {CARD_BG};
    alternate-background-color: #F7F9FC;
    gridline-color: {BORDER};
    border: 1px solid {BORDER};
    border-radius: 8px;
    selection-background-color: #DCE6F5;
    selection-color: {TEXT};
}}
QHeaderView::section {{
    background: {NAVY};
    color: white;
    padding: 8px;
    border: none;
    font-weight: 600;
}}
QTableWidget::item {{
    padding: 4px;
}}
QListWidget {{
    background: {CARD_BG};
    border: 1px solid {BORDER};
    border-radius: 8px;
}}

/* ---- tabs ---- */
QTabWidget::pane {{
    border: 1px solid {BORDER};
    border-radius: 8px;
    top: -1px;
    background: {CARD_BG};
}}
QTabBar::tab {{
    background: transparent;
    padding: 10px 18px;
    color: {MUTED};
    font-weight: 600;
    border-bottom: 2px solid transparent;
}}
QTabBar::tab:selected {{
    color: {NAVY};
    border-bottom: 2px solid {GOLD};
}}
QTabBar::tab:hover {{
    color: {NAVY_LIGHTER};
}}

/* ---- splitter ---- */
QSplitter::handle {{
    background: {BORDER};
    width: 2px;
}}

/* ---- scrollbars ---- */
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
}}
QScrollBar::handle:vertical {{
    background: #C7D0DE;
    border-radius: 5px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{
    background: {NAVY_LIGHTER};
}}
QScrollBar:horizontal {{
    background: transparent;
    height: 10px;
}}
QScrollBar::handle:horizontal {{
    background: #C7D0DE;
    border-radius: 5px;
}}

/* ---- checkboxes ---- */
QCheckBox {{
    spacing: 6px;
    background: transparent;
}}

/* ---- frame / cards ---- */
QFrame[cssClass="card"] {{
    background: {CARD_BG};
    border: 1px solid {BORDER};
    border-radius: 10px;
}}

/* ---- sidebar ---- */
QWidget#sidebar {{
    background: {NAVY};
}}
QLabel#sidebarTitle {{
    color: white;
    font-size: 19px;
    font-weight: 800;
    padding: 18px 10px 8px 10px;
}}
QLabel#sidebarUser {{
    color: #9FB3D1;
    padding: 8px 14px;
}}
QPushButton#navBtn {{
    background: transparent;
    color: #DCE6F5;
    border: none;
    border-radius: 8px;
    text-align: right;
    padding: 11px 16px;
    font-weight: 600;
}}
QPushButton#navBtn:hover {{
    background: {NAVY_LIGHT};
    color: white;
}}
QPushButton#navBtnActive {{
    background: {GOLD};
    color: {NAVY};
    border: none;
    border-radius: 8px;
    text-align: right;
    padding: 11px 16px;
    font-weight: 700;
}}
QPushButton#backupBtn {{
    background: {NAVY_LIGHT};
    color: white;
    border: 1px solid {NAVY_LIGHTER};
    border-radius: 8px;
    padding: 10px;
    margin: 8px 10px;
}}
QPushButton#backupBtn:hover {{
    background: {NAVY_LIGHTER};
}}

/* ---- stat cards ---- */
QFrame#statCard {{
    background: {NAVY};
    border-radius: 12px;
}}
QFrame#statCardAlt {{
    background: {NAVY_LIGHTER};
    border-radius: 12px;
}}

/* ---- message boxes / dialogs ---- */
QDialog {{
    background: {BG};
}}
"""


def style_table(table):
    """Apply consistent alternating rows / row height / hidden index column to a QTableWidget."""
    table.setAlternatingRowColors(True)
    table.verticalHeader().setVisible(False)
    table.verticalHeader().setDefaultSectionSize(30)
